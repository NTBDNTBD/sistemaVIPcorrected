"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { supabase } from "@/lib/supabase/client"
import { generateMemberCode, generateMemberQR } from "@/lib/qr-generator"
import { renewMembership } from "@/lib/membership-checker"
import { AuthGuard } from "@/components/auth-guard"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { QrCode, Plus, Award, RefreshCw } from "lucide-react"
import { demoMembers } from "@/lib/demo-data"
import { sendWelcomeNotification } from "@/lib/notification-sender"
import { sendRenewalNotification } from "@/lib/notification-sender"

interface VipMember {
  id: string
  member_code: string
  qr_code: string
  full_name: string
  email: string
  phone: string
  membership_start: string
  membership_end: string
  is_active: boolean
  total_spent: number
  loyalty_points: number
  created_at: string
}

export default function MembersPage() {
  const [members, setMembers] = useState<VipMember[]>([])
  const [loading, setLoading] = useState(true)
  const [showAddDialog, setShowAddDialog] = useState(false)
  const [showQRDialog, setShowQRDialog] = useState(false)
  const [selectedMember, setSelectedMember] = useState<VipMember | null>(null)
  const [submitting, setSubmitting] = useState(false)
  const [newMember, setNewMember] = useState({
    full_name: "",
    email: "",
    phone: "",
  })

  useEffect(() => {
    loadMembers()
  }, [])

  const loadMembers = async () => {
    try {
      const { data, error } = await supabase.from("vip_members").select("*").order("created_at", { ascending: false })

      if (error) throw error
      setMembers(data || [])
    } catch (error) {
      console.error("Error loading members:", error)
      // Fallback to demo data only if Supabase fails
      setMembers(demoMembers)
    } finally {
      setLoading(false)
    }
  }

  const handleAddMember = async (e: React.FormEvent) => {
    e.preventDefault()

    if (submitting) return

    if (!newMember.full_name.trim() || !newMember.email.trim()) {
      alert("Nombre y email son requeridos")
      return
    }

    setSubmitting(true)

    try {
      const memberCode = generateMemberCode()
      const qrCode = await generateMemberQR(memberCode)

      const membershipStart = new Date()
      const membershipEnd = new Date()
      membershipEnd.setDate(membershipEnd.getDate() + 90)

      const { data, error } = await supabase
        .from("vip_members")
        .insert({
          member_code: memberCode,
          qr_code: qrCode,
          full_name: newMember.full_name,
          email: newMember.email,
          phone: newMember.phone,
          membership_start: membershipStart.toISOString().split("T")[0],
          membership_end: membershipEnd.toISOString().split("T")[0],
          is_active: true,
        })
        .select()
        .single()

      if (error) throw error

      // Send welcome notification
      await sendWelcomeNotification(newMember.email, newMember.full_name)

      setNewMember({ full_name: "", email: "", phone: "" })
      setShowAddDialog(false)
      loadMembers()
      alert("Miembro agregado exitosamente")
    } catch (error) {
      console.error("Error adding member:", error)
      alert("Error al agregar miembro: " + (error as Error).message)
    } finally {
      setSubmitting(false)
    }
  }

  const handleRenewMembership = async (memberId: string) => {
    try {
      const member = members.find((m) => m.id === memberId)
      await renewMembership(memberId)

      if (member) {
        await sendRenewalNotification(member.email, member.full_name)
      }

      loadMembers()
    } catch (error) {
      console.error("Error renewing membership:", error)
    }
  }

  const getMembershipStatus = (member: VipMember) => {
    const today = new Date()
    const endDate = new Date(member.membership_end)
    const daysLeft = Math.ceil((endDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24))

    if (!member.is_active || daysLeft < 0) {
      return { status: "Vencida", variant: "destructive" as const, daysLeft: 0 }
    } else if (daysLeft <= 7) {
      return { status: "Por Vencer", variant: "secondary" as const, daysLeft }
    } else {
      return { status: "Activa", variant: "default" as const, daysLeft }
    }
  }

  if (loading) {
    return (
      <AuthGuard requiredPermission="manage_members">
        <div className="flex items-center justify-center min-h-screen">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </div>
      </AuthGuard>
    )
  }

  return (
    <AuthGuard requiredPermission="manage_members">
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Miembros VIP</h1>
            <p className="text-muted-foreground">Gestiona los miembros VIP y sus membresías</p>
          </div>
          <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Agregar Miembro
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Agregar Nuevo Miembro VIP</DialogTitle>
                <DialogDescription>
                  Completa la información del nuevo miembro. Se generará automáticamente un código QR único.
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleAddMember}>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="full_name">Nombre Completo</Label>
                    <Input
                      id="full_name"
                      value={newMember.full_name}
                      onChange={(e) => setNewMember((prev) => ({ ...prev, full_name: e.target.value }))}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={newMember.email}
                      onChange={(e) => setNewMember((prev) => ({ ...prev, email: e.target.value }))}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="phone">Teléfono</Label>
                    <Input
                      id="phone"
                      value={newMember.phone}
                      onChange={(e) => setNewMember((prev) => ({ ...prev, phone: e.target.value }))}
                    />
                  </div>
                </div>
                <DialogFooter className="mt-6">
                  <Button type="button" variant="outline" onClick={() => setShowAddDialog(false)}>
                    Cancelar
                  </Button>
                  <Button type="submit" disabled={submitting}>
                    {submitting ? "Creando..." : "Crear Miembro"}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Lista de Miembros</CardTitle>
            <CardDescription>Total de miembros: {members.length}</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Código</TableHead>
                  <TableHead>Nombre</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Estado</TableHead>
                  <TableHead>Gastos</TableHead>
                  <TableHead>Puntos</TableHead>
                  <TableHead>Acciones</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {members.map((member) => {
                  const membershipStatus = getMembershipStatus(member)
                  return (
                    <TableRow key={member.id}>
                      <TableCell className="font-mono">{member.member_code}</TableCell>
                      <TableCell>{member.full_name}</TableCell>
                      <TableCell>{member.email}</TableCell>
                      <TableCell>
                        <Badge variant={membershipStatus.variant}>
                          {membershipStatus.status}
                          {membershipStatus.daysLeft > 0 && ` (${membershipStatus.daysLeft}d)`}
                        </Badge>
                      </TableCell>
                      <TableCell>${member.total_spent.toFixed(2)}</TableCell>
                      <TableCell>
                        <div className="flex items-center">
                          <Award className="mr-1 h-4 w-4" />
                          {member.loyalty_points}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex space-x-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              setSelectedMember(member)
                              setShowQRDialog(true)
                            }}
                          >
                            <QrCode className="h-4 w-4" />
                          </Button>
                          {membershipStatus.status !== "Activa" && (
                            <Button variant="outline" size="sm" onClick={() => handleRenewMembership(member.id)}>
                              <RefreshCw className="h-4 w-4" />
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {/* Dialog para mostrar QR */}
        <Dialog open={showQRDialog} onOpenChange={setShowQRDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Código QR - {selectedMember?.full_name}</DialogTitle>
              <DialogDescription>Código único del miembro: {selectedMember?.member_code}</DialogDescription>
            </DialogHeader>
            <div className="flex justify-center p-6">
              {selectedMember && (
                <img
                  src={selectedMember.qr_code || "/placeholder.svg"}
                  alt={`QR Code for ${selectedMember.full_name}`}
                  className="w-64 h-64"
                />
              )}
            </div>
            <DialogFooter>
              <Button onClick={() => setShowQRDialog(false)}>Cerrar</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </AuthGuard>
  )
}
