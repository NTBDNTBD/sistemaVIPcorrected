"use client"

import { useEffect, useState } from "react"
import { getSupabaseClient, isDemo } from "@/lib/supabase"
import { AuthGuard } from "@/components/auth-guard"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { CreditCard, Smartphone, Banknote } from "lucide-react"
import { demoTransactions } from "@/lib/demo-data"

interface Transaction {
  id: string
  transaction_code: string
  member_id: string
  total_amount: number
  payment_method: string
  payment_status: string
  loyalty_points_earned: number
  created_at: string
}

export default function TransactionsPage() {
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const loadTransactions = async () => {
      try {
        if (isDemo()) {
          setTransactions(demoTransactions)
          setLoading(false)
          return
        }

        const supabase = getSupabaseClient()
        const { data, error } = await supabase
          .from("transactions")
          .select("*")
          .order("created_at", { ascending: false })
          .limit(50)

        if (error) throw error
        setTransactions(data || [])
      } catch (error) {
        console.error("Error loading transactions:", error)
        setTransactions(demoTransactions)
      } finally {
        setLoading(false)
      }
    }

    loadTransactions()
  }, [])

  const getPaymentIcon = (method: string) => {
    switch (method) {
      case "card":
        return <CreditCard className="h-4 w-4" />
      case "digital":
        return <Smartphone className="h-4 w-4" />
      case "cash":
        return <Banknote className="h-4 w-4" />
      default:
        return <CreditCard className="h-4 w-4" />
    }
  }

  const getPaymentMethodLabel = (method: string) => {
    switch (method) {
      case "card":
        return "Tarjeta"
      case "digital":
        return "Digital"
      case "cash":
        return "Efectivo"
      default:
        return method
    }
  }

  if (loading) {
    return (
      <AuthGuard requiredPermissions={["process_payments"]}>
        <div className="flex items-center justify-center min-h-screen">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </div>
      </AuthGuard>
    )
  }

  return (
    <AuthGuard requiredPermissions={["process_payments"]}>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Transacciones</h1>
          <p className="text-muted-foreground">
            Historial de transacciones y pagos
            {isDemo() && <span className="ml-2 text-orange-500">(Modo Demo)</span>}
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Transacciones Recientes</CardTitle>
            <CardDescription>Últimas {transactions.length} transacciones procesadas</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Código</TableHead>
                  <TableHead>Monto</TableHead>
                  <TableHead>Método de Pago</TableHead>
                  <TableHead>Estado</TableHead>
                  <TableHead>Puntos</TableHead>
                  <TableHead>Fecha</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {transactions.map((transaction) => (
                  <TableRow key={transaction.id}>
                    <TableCell className="font-mono">{transaction.transaction_code}</TableCell>
                    <TableCell className="font-semibold">${transaction.total_amount.toFixed(2)}</TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        {getPaymentIcon(transaction.payment_method)}
                        <span>{getPaymentMethodLabel(transaction.payment_method)}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant={transaction.payment_status === "completed" ? "default" : "secondary"}>
                        {transaction.payment_status === "completed" ? "Completado" : "Pendiente"}
                      </Badge>
                    </TableCell>
                    <TableCell>{transaction.loyalty_points_earned} pts</TableCell>
                    <TableCell>{new Date(transaction.created_at).toLocaleDateString()}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </AuthGuard>
  )
}
