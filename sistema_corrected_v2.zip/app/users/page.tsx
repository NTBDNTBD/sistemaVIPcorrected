"use client"

import { useState } from "react"
import { AuthGuard } from "@/components/auth-guard"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { useToast } from "@/hooks/use-toast"
import { generateSecurePassword } from "@/lib/auth-utils"
import { resetPassword } from "@/lib/auth"
import {
  UserCog,
  Plus,
  Search,
  Edit,
  Trash2,
  Key,
  Eye,
  EyeOff,
  Shield,
  Crown,
  Briefcase,
  Calculator,
  AlertTriangle,
  CheckCircle,
  XCircle,
} from "lucide-react"

interface SystemUser {
  id: string
  email: string
  full_name: string
  role: {
    name: string
    display_name: string
    permissions: Record<string, boolean>
  }
  status: "active" | "inactive"
  password_changed: boolean
  last_login?: string
  created_at: string
}

// Demo users data
const DEMO_USERS: SystemUser[] = [
  {
    id: "1",
    email: "admin@barvip.com",
    full_name: "Administrador Principal",
    role: {
      name: "admin",
      display_name: "Administrador",
      permissions: {
        manage_users: true,
        manage_members: true,
        manage_products: true,
        process_payments: true,
        view_reports: true,
        manage_settings: true,
        manage_notifications: true,
        view_analytics: true,
      },
    },
    status: "active",
    password_changed: false,
    last_login: "2024-01-20T10:30:00Z",
    created_at: "2024-01-01T00:00:00Z",
  },
  {
    id: "2",
    email: "gerente@barvip.com",
    full_name: "María González",
    role: {
      name: "manager",
      display_name: "Gerente",
      permissions: {
        manage_users: false,
        manage_members: true,
        manage_products: false,
        process_payments: true,
        view_reports: true,
        manage_settings: false,
        manage_notifications: true,
        view_analytics: true,
      },
    },
    status: "active",
    password_changed: true,
    last_login: "2024-01-19T15:45:00Z",
    created_at: "2024-01-02T00:00:00Z",
  },
  {
    id: "3",
    email: "cajero1@barvip.com",
    full_name: "Carlos Rodríguez",
    role: {
      name: "cashier",
      display_name: "Cajero",
      permissions: {
        manage_users: false,
        manage_members: false,
        manage_products: false,
        process_payments: true,
        view_reports: false,
        manage_settings: false,
        manage_notifications: false,
        view_analytics: false,
      },
    },
    status: "active",
    password_changed: true,
    last_login: "2024-01-20T08:15:00Z",
    created_at: "2024-01-03T00:00:00Z",
  },
]

export default function UsersPage() {
  return (
    <AuthGuard requiredPermission="manage_users">
      <UsersContent />
    </AuthGuard>
  )
}

function UsersContent() {
  const [users, setUsers] = useState<SystemUser[]>(DEMO_USERS)
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedRole, setSelectedRole] = useState("all")
  const [showPasswords, setShowPasswords] = useState(false)
  const { toast } = useToast()

  const roles = ["all", "admin", "manager", "cashier"]

  const filteredUsers = users.filter((user) => {
    const matchesSearch =
      user.full_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.email.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesRole = selectedRole === "all" || user.role.name === selectedRole
    return matchesSearch && matchesRole
  })

  const getRoleIcon = (roleName: string) => {
    switch (roleName) {
      case "admin":
        return Crown
      case "manager":
        return Briefcase
      case "cashier":
        return Calculator
      default:
        return UserCog
    }
  }

  const getRoleColor = (roleName: string) => {
    switch (roleName) {
      case "admin":
        return "destructive"
      case "manager":
        return "default"
      case "cashier":
        return "secondary"
      default:
        return "outline"
    }
  }

  const handleResetPassword = async (userId: string, userName: string) => {
    try {
      const newPassword = generateSecurePassword()
      await resetPassword(userId, newPassword)

      toast({
        title: "Contraseña Restablecida",
        description: `Nueva contraseña para ${userName}: ${newPassword}`,
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "No se pudo restablecer la contraseña",
        variant: "destructive",
      })
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("es-ES", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Gestión de Usuarios</h1>
          <p className="text-muted-foreground">Administra usuarios del sistema y sus permisos</p>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            onClick={() => setShowPasswords(!showPasswords)}
            className="flex items-center gap-2"
          >
            {showPasswords ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            {showPasswords ? "Ocultar Info" : "Mostrar Info"}
          </Button>
          <Button className="flex items-center gap-2">
            <Plus className="h-4 w-4" />
            Nuevo Usuario
          </Button>
        </div>
      </div>

      {/* Security Warning */}
      <Alert className="border-red-200 bg-red-50">
        <Shield className="h-4 w-4" />
        <AlertDescription>
          <strong>Área de Alta Seguridad:</strong> La gestión de usuarios permite crear, modificar y eliminar cuentas
          del sistema. Solo administradores autorizados deben tener acceso a esta funcionalidad crítica.
        </AlertDescription>
      </Alert>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Search className="h-5 w-5" />
            Filtros de Búsqueda
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="search">Buscar usuarios</Label>
              <Input
                id="search"
                placeholder="Nombre o email..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="role">Rol</Label>
              <select
                id="role"
                className="w-full p-2 border rounded-md"
                value={selectedRole}
                onChange={(e) => setSelectedRole(e.target.value)}
              >
                <option value="all">Todos los roles</option>
                <option value="admin">Administrador</option>
                <option value="manager">Gerente</option>
                <option value="cashier">Cajero</option>
              </select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Users Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredUsers.map((user) => {
          const RoleIcon = getRoleIcon(user.role.name)

          return (
            <Card key={user.id} className="relative">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div
                      className={`p-2 rounded-full ${
                        user.role.name === "admin"
                          ? "bg-red-100"
                          : user.role.name === "manager"
                            ? "bg-blue-100"
                            : "bg-green-100"
                      }`}
                    >
                      <RoleIcon
                        className={`h-4 w-4 ${
                          user.role.name === "admin"
                            ? "text-red-600"
                            : user.role.name === "manager"
                              ? "text-blue-600"
                              : "text-green-600"
                        }`}
                      />
                    </div>
                    <div>
                      <CardTitle className="text-lg">{user.full_name}</CardTitle>
                      <CardDescription>{user.email}</CardDescription>
                    </div>
                  </div>
                  <Badge variant={getRoleColor(user.role.name)}>{user.role.display_name}</Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <Label>Estado</Label>
                    <div className="flex items-center gap-1">
                      {user.status === "active" ? (
                        <CheckCircle className="h-4 w-4 text-green-600" />
                      ) : (
                        <XCircle className="h-4 w-4 text-red-600" />
                      )}
                      <span className={user.status === "active" ? "text-green-600" : "text-red-600"}>
                        {user.status === "active" ? "Activo" : "Inactivo"}
                      </span>
                    </div>
                  </div>
                  <div>
                    <Label>Contraseña</Label>
                    <div className="flex items-center gap-1">
                      {user.password_changed ? (
                        <CheckCircle className="h-4 w-4 text-green-600" />
                      ) : (
                        <AlertTriangle className="h-4 w-4 text-orange-600" />
                      )}
                      <span className={user.password_changed ? "text-green-600" : "text-orange-600"}>
                        {user.password_changed ? "Cambiada" : "Por cambiar"}
                      </span>
                    </div>
                  </div>
                </div>

                {showPasswords && (
                  <div className="p-3 bg-gray-50 border border-gray-200 rounded-lg">
                    <Label className="text-xs font-medium">Información Sensible</Label>
                    <div className="text-xs text-gray-600 mt-1 space-y-1">
                      <div>ID: {user.id}</div>
                      <div>Creado: {formatDate(user.created_at)}</div>
                      {user.last_login && <div>Último acceso: {formatDate(user.last_login)}</div>}
                    </div>
                  </div>
                )}

                <div>
                  <Label className="text-xs">Permisos</Label>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {Object.entries(user.role.permissions)
                      .filter(([_, hasPermission]) => hasPermission)
                      .slice(0, 3)
                      .map(([permission]) => (
                        <Badge key={permission} variant="outline" className="text-xs">
                          {permission.replace("manage_", "").replace("_", " ")}
                        </Badge>
                      ))}
                    {Object.values(user.role.permissions).filter((p) => p).length > 3 && (
                      <Badge variant="outline" className="text-xs">
                        +{Object.values(user.role.permissions).filter((p) => p).length - 3} más
                      </Badge>
                    )}
                  </div>
                </div>

                <div className="flex gap-2">
                  <Button variant="outline" size="sm" className="flex-1 bg-transparent">
                    <Edit className="h-4 w-4 mr-1" />
                    Editar
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => handleResetPassword(user.id, user.full_name)}>
                    <Key className="h-4 w-4" />
                  </Button>
                  <Button variant="outline" size="sm" className="text-red-600 bg-transparent">
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {filteredUsers.length === 0 && (
        <Card>
          <CardContent className="text-center py-8">
            <UserCog className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">No se encontraron usuarios</h3>
            <p className="text-muted-foreground">Intenta ajustar los filtros de búsqueda o agrega nuevos usuarios.</p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
