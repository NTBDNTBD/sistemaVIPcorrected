"use client"

import { useEffect, useState } from "react"
import { getSupabaseClient, isDemo } from "@/lib/supabase"
import { AuthGuard } from "@/components/auth-guard"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { QrCode, Search, Download } from "lucide-react"
import { demoMembers } from "@/lib/demo-data"

interface VipMember {
  id: string
  member_code: string
  qr_code: string
  full_name: string
  email: string
  is_active: boolean
}

export default function QRCodesPage() {
  const [members, setMembers] = useState<VipMember[]>([])
  const [filteredMembers, setFilteredMembers] = useState<VipMember[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const loadMembers = async () => {
      try {
        if (isDemo()) {
          setMembers(demoMembers)
          setFilteredMembers(demoMembers)
          setLoading(false)
          return
        }

        const supabase = getSupabaseClient()
        const { data, error } = await supabase
          .from("vip_members")
          .select("id, member_code, qr_code, full_name, email, is_active")
          .order("full_name")

        if (error) throw error
        setMembers(data || [])
        setFilteredMembers(data || [])
      } catch (error) {
        console.error("Error loading members:", error)
        setMembers(demoMembers)
        setFilteredMembers(demoMembers)
      } finally {
        setLoading(false)
      }
    }

    loadMembers()
  }, [])

  useEffect(() => {
    const filtered = members.filter(
      (member) =>
        member.full_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        member.member_code.toLowerCase().includes(searchTerm.toLowerCase()) ||
        member.email.toLowerCase().includes(searchTerm.toLowerCase()),
    )
    setFilteredMembers(filtered)
  }, [searchTerm, members])

  const downloadQR = (member: VipMember) => {
    // Create a download link for the QR code
    const link = document.createElement("a")
    link.href = member.qr_code
    link.download = `QR_${member.member_code}.png`
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  if (loading) {
    return (
      <AuthGuard requiredPermissions={["manage_members"]}>
        <div className="flex items-center justify-center min-h-screen">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </div>
      </AuthGuard>
    )
  }

  return (
    <AuthGuard requiredPermissions={["manage_members"]}>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Códigos QR</h1>
          <p className="text-muted-foreground">
            Gestiona y descarga los códigos QR de los miembros VIP
            {isDemo() && <span className="ml-2 text-orange-500">(Modo Demo)</span>}
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Buscar Miembros</CardTitle>
            <CardDescription>Encuentra códigos QR por nombre, código de miembro o email</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center space-x-2">
              <Search className="h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Buscar por nombre, código o email..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="max-w-sm"
              />
            </div>
          </CardContent>
        </Card>

        {isDemo() && (
          <Alert>
            <QrCode className="h-4 w-4" />
            <AlertDescription>
              En modo demo, los códigos QR son imágenes de placeholder. En producción, estos serían códigos QR reales
              generados para cada miembro.
            </AlertDescription>
          </Alert>
        )}

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {filteredMembers.map((member) => (
            <Card key={member.id}>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-lg">{member.full_name}</CardTitle>
                    <CardDescription className="font-mono">{member.member_code}</CardDescription>
                  </div>
                  <Badge variant={member.is_active ? "default" : "secondary"}>
                    {member.is_active ? "Activo" : "Inactivo"}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-center">
                  <img
                    src={member.qr_code || "/placeholder.svg?height=150&width=150&text=QR"}
                    alt={`QR Code for ${member.full_name}`}
                    className="w-32 h-32 border rounded"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-sm text-muted-foreground">Email</Label>
                  <p className="text-sm">{member.email}</p>
                </div>
                <Button onClick={() => downloadQR(member)} className="w-full" variant="outline">
                  <Download className="mr-2 h-4 w-4" />
                  Descargar QR
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredMembers.length === 0 && (
          <Card>
            <CardContent className="text-center py-8">
              <QrCode className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">No se encontraron miembros</h3>
              <p className="text-muted-foreground">
                {searchTerm ? "Intenta con otros términos de búsqueda" : "No hay miembros registrados"}
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </AuthGuard>
  )
}
