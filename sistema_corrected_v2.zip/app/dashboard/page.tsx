"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  AlertTriangle,
  Package,
  DollarSign,
  TrendingUp,
  ShoppingCart,
  BarChart3,
  Settings,
  Users,
  Truck,
  FileText,
} from "lucide-react"
import { supabase } from "@/lib/supabase/client"
import { toast } from "sonner"
import Link from "next/link"
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, BarChart, Bar } from "recharts"
import { useAuth } from "@/contexts/auth-context"
import { isDemo } from "@/lib/supabase/client"



interface DashboardStats {
  totalProducts: number
  lowStockProducts: number
  todayRevenue: number
  monthlyRevenue: number
  totalTransactions: number
  totalStock: number
  categoriesCount: number
}

interface LowStockProduct {
  id: string
  name: string
  stock: number
  min_stock: number
  category: string
}

interface SalesData {
  date: string
  sales: number
  revenue: number
}

const demoStats: DashboardStats = {
  totalProducts: 45,
  lowStockProducts: 3,
  todayRevenue: 2450.75,
  monthlyRevenue: 18750.25,
  totalTransactions: 127,
  totalStock: 890,
  categoriesCount: 8,
}

const demoLowStockProducts: LowStockProduct[] = [
  { id: "1", name: "Whisky Premium", stock: 2, min_stock: 5, category: "Bebidas Premium" },
  { id: "2", name: "Vino Tinto Reserva", stock: 1, min_stock: 3, category: "Vinos" },
  { id: "3", name: "Tabla de Quesos", stock: 0, min_stock: 2, category: "Aperitivos" },
]

const demoSalesData: SalesData[] = [
  { date: "Lun", sales: 12, revenue: 1250.5 },
  { date: "Mar", sales: 18, revenue: 1890.75 },
  { date: "Mié", sales: 15, revenue: 1650.25 },
  { date: "Jue", sales: 22, revenue: 2340.8 },
  { date: "Vie", sales: 28, revenue: 3120.45 },
  { date: "Sáb", sales: 35, revenue: 4250.9 },
  { date: "Dom", sales: 25, revenue: 2890.6 },
]

export const dynamic = 'force-dynamic'

export default function DashboardPage() {
  const { user } = useAuth()
  const [stats, setStats] = useState<DashboardStats>(demoStats)
  const [lowStockProducts, setLowStockProducts] = useState<LowStockProduct[]>(demoLowStockProducts)
  const [salesData, setSalesData] = useState<SalesData[]>(demoSalesData)
  const [loading, setLoading] = useState(true)

  const getUserRole = () => {
    if (!user?.email) return "cajero"
    if (user.email === "manager@barvip.com") return "administrador"
    if (user.email?.includes("gerente") || user.email?.includes("manager")) return "gerente"
    return "cajero"
  }

  const userRole = getUserRole()

  useEffect(() => {
    loadDashboardData()
  }, [])

  const loadDashboardData = async () => {
    try {
      if (isDemo()) {
        setStats(demoStats)
        setLowStockProducts(demoLowStockProducts)
        setSalesData(demoSalesData)
        setLoading(false)
        return
      }

      const [productsResult, lowStockResult, transactionsResult, todayTransactionsResult, monthlyTransactionsResult] =
        await Promise.all([
          supabase.from("products").select("*").eq("is_active", true),
          supabase
            .from("products")
            .select("id, name, stock, min_stock, category")
            .eq("is_active", true)
            .filter("stock", "lte", "min_stock"),
          supabase.from("transactions").select("*").order("created_at", { ascending: false }),
          supabase.from("transactions").select("amount").gte("created_at", new Date().toISOString().split("T")[0]),
          supabase
            .from("transactions")
            .select("amount")
            .gte("created_at", new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString()),
        ])

      const products = productsResult.data || []
      const transactions = transactionsResult.data || []
      const todayTransactions = todayTransactionsResult.data || []
      const monthlyTransactions = monthlyTransactionsResult.data || []

      const todayRevenue = todayTransactions.reduce((sum, t) => sum + Number(t.amount || 0), 0)
      const monthlyRevenue = monthlyTransactions.reduce((sum, t) => sum + Number(t.amount || 0), 0)
      const totalStock = products.reduce((sum, p) => sum + Number(p.stock || 0), 0)
      const categories = [...new Set(products.map((p) => p.category))].length

      // Generate sales data for the last 7 days
      const salesDataArray: SalesData[] = []
      for (let i = 6; i >= 0; i--) {
        const date = new Date()
        date.setDate(date.getDate() - i)
        const dateStr = date.toISOString().split("T")[0]
        const dayTransactions = transactions.filter((t) => t.created_at?.startsWith(dateStr))
        const dayRevenue = dayTransactions.reduce((sum, t) => sum + Number(t.amount || 0), 0)

        salesDataArray.push({
          date: date.toLocaleDateString("es-ES", { month: "short", day: "numeric" }),
          sales: dayTransactions.length,
          revenue: dayRevenue,
        })
      }

      setStats({
        totalProducts: products.length,
        lowStockProducts: lowStockResult.data?.length || 0,
        todayRevenue,
        monthlyRevenue,
        totalTransactions: transactions.length,
        totalStock,
        categoriesCount: categories,
      })

      setLowStockProducts(lowStockResult.data || [])
      setSalesData(salesDataArray)
    } catch (error) {
      console.error("Error loading dashboard data:", error)
      setStats(demoStats)
      setLowStockProducts(demoLowStockProducts)
      setSalesData(demoSalesData)
      toast.error("Error al cargar datos del dashboard - usando datos demo")
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="border-b">
        <div className="flex h-16 items-center px-4">
          <BarChart3 className="h-6 w-6 mr-2" />
          <h1 className="text-xl font-semibold">Dashboard Administrativo</h1>
          {isDemo() && (
            <Badge variant="outline" className="ml-2">
              Modo Demo
            </Badge>
          )}
        </div>
      </div>

      <div className="flex-1 space-y-4 p-8 pt-6">
        <div className="flex items-center justify-between">
          <h2 className="text-3xl font-bold tracking-tight">{"La EX's Bar VIP"}</h2>
          <div className="flex items-center space-x-2">
            <Button asChild>
              <Link href="/pos">
                <ShoppingCart className="mr-2 h-4 w-4" />
                Abrir POS
              </Link>
            </Button>
          </div>
        </div>

        {/* Alertas de stock bajo */}
        {lowStockProducts.length > 0 && (
          <Alert variant="destructive">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              <div className="flex justify-between items-center">
                <span>
                  {lowStockProducts.length} producto{lowStockProducts.length > 1 ? "s" : ""} con stock bajo
                </span>
                <Button variant="outline" size="sm" asChild>
                  <Link href="/products">Ver Productos</Link>
                </Button>
              </div>
            </AlertDescription>
          </Alert>
        )}

        <Tabs defaultValue="overview" className="space-y-4">
          <TabsList>
            <TabsTrigger value="overview">Resumen</TabsTrigger>
            <TabsTrigger value="sales">Ventas</TabsTrigger>
            <TabsTrigger value="inventory">Inventario</TabsTrigger>
            <TabsTrigger value="quick-actions">Acciones Rápidas</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4">
            {/* Estadísticas principales */}
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Productos</CardTitle>
                  <Package className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats.totalProducts}</div>
                  <p className="text-xs text-muted-foreground">{stats.categoriesCount} categorías</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Ingresos Hoy</CardTitle>
                  <DollarSign className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">${stats.todayRevenue.toFixed(2)}</div>
                  <p className="text-xs text-muted-foreground">Ventas del día</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Ingresos Mensuales</CardTitle>
                  <TrendingUp className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">${stats.monthlyRevenue.toFixed(2)}</div>
                  <p className="text-xs text-muted-foreground">Mes actual</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Stock Total</CardTitle>
                  <Package className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats.totalStock}</div>
                  <p className="text-xs text-muted-foreground">
                    {stats.lowStockProducts > 0 && (
                      <span className="text-red-500">{stats.lowStockProducts} con stock bajo</span>
                    )}
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Gráfico de ventas */}
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
              <Card className="col-span-4">
                <CardHeader>
                  <CardTitle>Ventas de los Últimos 7 Días</CardTitle>
                </CardHeader>
                <CardContent className="pl-2">
                  <ResponsiveContainer width="100%" height={350}>
                    <LineChart data={salesData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis />
                      <Tooltip />
                      <Line type="monotone" dataKey="revenue" stroke="#8884d8" strokeWidth={2} />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card className="col-span-3">
                <CardHeader>
                  <CardTitle>Productos con Stock Bajo</CardTitle>
                  <CardDescription>Requieren reabastecimiento urgente</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {lowStockProducts.slice(0, 5).map((product) => (
                      <div key={product.id} className="flex items-center justify-between">
                        <div className="space-y-1">
                          <p className="text-sm font-medium leading-none">{product.name}</p>
                          <p className="text-xs text-muted-foreground">{product.category}</p>
                        </div>
                        <Badge variant="destructive">
                          {product.stock}/{product.min_stock}
                        </Badge>
                      </div>
                    ))}
                    {lowStockProducts.length === 0 && (
                      <p className="text-sm text-muted-foreground">No hay productos con stock bajo</p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="sales" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Ingresos por Día</CardTitle>
                  <CardDescription>Últimos 7 días</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={salesData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="revenue" fill="#8884d8" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Transacciones por Día</CardTitle>
                  <CardDescription>Últimos 7 días</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={salesData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="sales" fill="#82ca9d" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="inventory" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-3">
              <Card>
                <CardHeader>
                  <CardTitle>Resumen de Inventario</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="flex justify-between">
                    <span>Total de productos:</span>
                    <span className="font-medium">{stats.totalProducts}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Stock total:</span>
                    <span className="font-medium">{stats.totalStock}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Categorías:</span>
                    <span className="font-medium">{stats.categoriesCount}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Stock bajo:</span>
                    <span className="font-medium text-red-500">{stats.lowStockProducts}</span>
                  </div>
                </CardContent>
              </Card>

              <Card className="col-span-2">
                <CardHeader>
                  <CardTitle>Productos con Stock Crítico</CardTitle>
                  <CardDescription>Productos que necesitan reabastecimiento inmediato</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {lowStockProducts.map((product) => (
                      <div key={product.id} className="flex items-center justify-between p-2 border rounded">
                        <div>
                          <p className="font-medium">{product.name}</p>
                          <p className="text-sm text-muted-foreground">{product.category}</p>
                        </div>
                        <div className="text-right">
                          <Badge variant="destructive">Stock: {product.stock}</Badge>
                          <p className="text-xs text-muted-foreground">Mín: {product.min_stock}</p>
                        </div>
                      </div>
                    ))}
                    {lowStockProducts.length === 0 && (
                      <p className="text-center text-muted-foreground py-4">
                        Todos los productos tienen stock suficiente
                      </p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="quick-actions" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              <Card className="cursor-pointer hover:shadow-md transition-shadow">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <ShoppingCart className="mr-2 h-5 w-5" />
                    Sistema POS
                  </CardTitle>
                  <CardDescription>Procesar ventas y gestionar transacciones</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button asChild className="w-full">
                    <Link href="/pos">Abrir POS</Link>
                  </Button>
                </CardContent>
              </Card>

              {(userRole === "administrador" || userRole === "gerente") && (
                <Card className="cursor-pointer hover:shadow-md transition-shadow">
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Package className="mr-2 h-5 w-5" />
                      Gestión de Productos
                    </CardTitle>
                    <CardDescription>Agregar, editar y gestionar inventario</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button asChild className="w-full">
                      <Link href="/products">Gestionar Productos</Link>
                    </Button>
                  </CardContent>
                </Card>
              )}

              {(userRole === "administrador" || userRole === "gerente") && (
                <Card className="cursor-pointer hover:shadow-md transition-shadow">
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Truck className="mr-2 h-5 w-5" />
                      Compras al Por Mayor
                    </CardTitle>
                    <CardDescription>Gestionar pedidos y proveedores</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button asChild className="w-full">
                      <Link href="/wholesale">Gestionar Compras</Link>
                    </Button>
                  </CardContent>
                </Card>
              )}

              {(userRole === "administrador" || userRole === "gerente") && (
                <Card className="cursor-pointer hover:shadow-md transition-shadow">
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <FileText className="mr-2 h-5 w-5" />
                      Reportes y Análisis
                    </CardTitle>
                    <CardDescription>Ver reportes detallados de ventas</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button asChild className="w-full">
                      <Link href="/reports">Ver Reportes</Link>
                    </Button>
                  </CardContent>
                </Card>
              )}

              {userRole === "administrador" && (
                <Card className="cursor-pointer hover:shadow-md transition-shadow">
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Users className="mr-2 h-5 w-5" />
                      Gestión de Usuarios
                    </CardTitle>
                    <CardDescription>Administrar usuarios del sistema</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button asChild className="w-full">
                      <Link href="/admin/users">Gestionar Usuarios</Link>
                    </Button>
                  </CardContent>
                </Card>
              )}

              {userRole === "administrador" && (
                <Card className="cursor-pointer hover:shadow-md transition-shadow">
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Settings className="mr-2 h-5 w-5" />
                      Configuración
                    </CardTitle>
                    <CardDescription>Configurar sistema y preferencias</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button asChild className="w-full">
                      <Link href="/settings">Configuración</Link>
                    </Button>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
