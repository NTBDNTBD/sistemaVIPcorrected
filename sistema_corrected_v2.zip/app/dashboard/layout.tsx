import type React from "react"
import { getCurrentUser } from "@/lib/auth"
import { DashboardLayout } from "@/components/dashboard-layout"
import { redirect } from "next/navigation"

export default async function DashboardLayoutPage({
  children,
}: {
  children: React.ReactNode
}) {
  try {
    const user = await getCurrentUser()

    if (!user) {
      redirect("/login")
    }

    return <DashboardLayout user={user}>{children}</DashboardLayout>
  } catch (error) {
    console.error("Dashboard layout error:", error)
    redirect("/login")
  }
}
