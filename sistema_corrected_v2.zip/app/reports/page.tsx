"use client"

import { useEffect, useState } from "react"
import { getSupabaseClient, isDemo } from "@/lib/supabase"
import { AuthGuard } from "@/components/auth-guard"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { DatePickerWithRange } from "@/components/ui/date-range-picker"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
} from "recharts"
import { TrendingUp, Users, DollarSign, Calendar, Download } from "lucide-react"

interface ReportData {
  membershipStats: {
    total: number
    active: number
    expired: number
    expiring: number
  }
  revenueStats: {
    daily: Array<{ date: string; amount: number }>
    monthly: Array<{ month: string; amount: number }>
    byPaymentMethod: Array<{ method: string; amount: number; count: number }>
  }
  membershipTrends: Array<{ date: string; new: number; renewed: number; expired: number }>
  topSpenders: Array<{ name: string; amount: number; transactions: number }>
}

const demoReportData: ReportData = {
  membershipStats: {
    total: 3,
    active: 2,
    expired: 1,
    expiring: 1,
  },
  revenueStats: {
    daily: [
      { date: "2024-01-01", amount: 450 },
      { date: "2024-01-02", amount: 320 },
      { date: "2024-01-03", amount: 680 },
      { date: "2024-01-04", amount: 520 },
      { date: "2024-01-05", amount: 750 },
    ],
    monthly: [
      { month: "Ene", amount: 12500 },
      { month: "Feb", amount: 15200 },
      { month: "Mar", amount: 18900 },
      { month: "Abr", amount: 16800 },
    ],
    byPaymentMethod: [
      { method: "Tarjeta", amount: 25000, count: 45 },
      { method: "Efectivo", amount: 15000, count: 30 },
      { method: "Digital", amount: 8000, count: 20 },
    ],
  },
  membershipTrends: [
    { date: "2024-01-01", new: 5, renewed: 2, expired: 1 },
    { date: "2024-01-02", new: 3, renewed: 4, expired: 0 },
    { date: "2024-01-03", new: 7, renewed: 1, expired: 2 },
    { date: "2024-01-04", new: 4, renewed: 3, expired: 1 },
  ],
  topSpenders: [
    { name: "Juan Pérez", amount: 1250.5, transactions: 8 },
    { name: "María García", amount: 890.25, transactions: 6 },
    { name: "Carlos López", amount: 2100.75, transactions: 12 },
  ],
}

const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#8884D8"]

export default function ReportsPage() {
  const [reportData, setReportData] = useState<ReportData>(demoReportData)
  const [loading, setLoading] = useState(true)
  const [dateRange, setDateRange] = useState<{ from: Date; to: Date }>({
    from: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
    to: new Date(),
  })
  const [reportType, setReportType] = useState("overview")

  useEffect(() => {
    loadReportData()
  }, [dateRange])

  const loadReportData = async () => {
    try {
      if (isDemo()) {
        setReportData(demoReportData)
        setLoading(false)
        return
      }

      const supabase = getSupabaseClient()

      // Cargar estadísticas de membresías
      const [membersResult, transactionsResult] = await Promise.all([
        supabase.from("vip_members").select("*"),
        supabase
          .from("transactions")
          .select("*")
          .gte("created_at", dateRange.from.toISOString())
          .lte("created_at", dateRange.to.toISOString()),
      ])

      const members = membersResult.data || []
      const transactions = transactionsResult.data || []

      // Procesar datos para reportes
      const membershipStats = {
        total: members.length,
        active: members.filter((m) => m.is_active).length,
        expired: members.filter((m) => !m.is_active).length,
        expiring: members.filter((m) => {
          const endDate = new Date(m.membership_end)
          const today = new Date()
          const daysLeft = Math.ceil((endDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24))
          return daysLeft <= 7 && daysLeft > 0
        }).length,
      }

      // Agrupar transacciones por día
      const dailyRevenue = transactions.reduce(
        (acc, t) => {
          const date = new Date(t.created_at).toISOString().split("T")[0]
          acc[date] = (acc[date] || 0) + Number(t.total_amount)
          return acc
        },
        {} as Record<string, number>,
      )

      const revenueStats = {
        daily: Object.entries(dailyRevenue).map(([date, amount]) => ({ date, amount })),
        monthly: [], // Implementar agrupación mensual
        byPaymentMethod: transactions.reduce(
          (acc, t) => {
            const existing = acc.find((item) => item.method === t.payment_method)
            if (existing) {
              existing.amount += Number(t.total_amount)
              existing.count += 1
            } else {
              acc.push({
                method: t.payment_method,
                amount: Number(t.total_amount),
                count: 1,
              })
            }
            return acc
          },
          [] as Array<{ method: string; amount: number; count: number }>,
        ),
      }

      setReportData({
        membershipStats,
        revenueStats,
        membershipTrends: [], // Implementar tendencias
        topSpenders: [], // Implementar top gastadores
      })
    } catch (error) {
      console.error("Error loading report data:", error)
      setReportData(demoReportData)
    } finally {
      setLoading(false)
    }
  }

  const exportReport = () => {
    const csvData = [
      ["Tipo", "Valor"],
      ["Miembros Totales", reportData.membershipStats.total],
      ["Miembros Activos", reportData.membershipStats.active],
      ["Miembros Vencidos", reportData.membershipStats.expired],
      ["Miembros por Vencer", reportData.membershipStats.expiring],
    ]

    const csvContent = csvData.map((row) => row.join(",")).join("\n")
    const blob = new Blob([csvContent], { type: "text/csv" })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `reporte-${new Date().toISOString().split("T")[0]}.csv`
    a.click()
    window.URL.revokeObjectURL(url)
  }

  if (loading) {
    return (
      <AuthGuard requiredPermissions={["view_reports"]}>
        <div className="flex items-center justify-center min-h-screen">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </div>
      </AuthGuard>
    )
  }

  return (
    <AuthGuard requiredPermissions={["view_reports"]}>
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Reportes y Análisis</h1>
            <p className="text-muted-foreground">
              Análisis detallado del rendimiento del bar VIP
              {isDemo() && <span className="ml-2 text-orange-500">(Datos Demo)</span>}
            </p>
          </div>
          <div className="flex space-x-2">
            <DatePickerWithRange date={dateRange} onDateChange={(range) => range && setDateRange(range)} />
            <Button onClick={exportReport} variant="outline">
              <Download className="mr-2 h-4 w-4" />
              Exportar
            </Button>
          </div>
        </div>

        {/* Métricas principales */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Miembros Totales</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{reportData.membershipStats.total}</div>
              <p className="text-xs text-muted-foreground">{reportData.membershipStats.active} activos</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Ingresos Totales</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                ${reportData.revenueStats.byPaymentMethod.reduce((sum, item) => sum + item.amount, 0).toLocaleString()}
              </div>
              <p className="text-xs text-muted-foreground">
                {reportData.revenueStats.byPaymentMethod.reduce((sum, item) => sum + item.count, 0)} transacciones
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Por Vencer</CardTitle>
              <Calendar className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-orange-600">{reportData.membershipStats.expiring}</div>
              <p className="text-xs text-muted-foreground">Próximos 7 días</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Tasa de Renovación</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">85%</div>
              <p className="text-xs text-muted-foreground">Últimos 30 días</p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="revenue" className="space-y-4">
          <TabsList>
            <TabsTrigger value="revenue">Ingresos</TabsTrigger>
            <TabsTrigger value="members">Membresías</TabsTrigger>
            <TabsTrigger value="payments">Métodos de Pago</TabsTrigger>
            <TabsTrigger value="trends">Tendencias</TabsTrigger>
          </TabsList>

          <TabsContent value="revenue">
            <Card>
              <CardHeader>
                <CardTitle>Ingresos Diarios</CardTitle>
                <CardDescription>Evolución de ingresos en el período seleccionado</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={reportData.revenueStats.daily}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip formatter={(value) => [`$${value}`, "Ingresos"]} />
                    <Line type="monotone" dataKey="amount" stroke="#8884d8" strokeWidth={2} />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="members">
            <div className="grid gap-4 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Estado de Membresías</CardTitle>
                  <CardDescription>Distribución actual de membresías</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={250}>
                    <PieChart>
                      <Pie
                        data={[
                          { name: "Activas", value: reportData.membershipStats.active },
                          { name: "Vencidas", value: reportData.membershipStats.expired },
                          { name: "Por Vencer", value: reportData.membershipStats.expiring },
                        ]}
                        cx="50%"
                        cy="50%"
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        label
                      >
                        {[
                          { name: "Activas", value: reportData.membershipStats.active },
                          { name: "Vencidas", value: reportData.membershipStats.expired },
                          { name: "Por Vencer", value: reportData.membershipStats.expiring },
                        ].map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Top Gastadores</CardTitle>
                  <CardDescription>Miembros con mayor gasto</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {reportData.topSpenders.map((spender, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">{spender.name}</p>
                          <p className="text-sm text-muted-foreground">{spender.transactions} transacciones</p>
                        </div>
                        <Badge variant="outline">${spender.amount.toFixed(2)}</Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="payments">
            <Card>
              <CardHeader>
                <CardTitle>Métodos de Pago</CardTitle>
                <CardDescription>Distribución de ingresos por método de pago</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={reportData.revenueStats.byPaymentMethod}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="method" />
                    <YAxis />
                    <Tooltip formatter={(value) => [`$${value}`, "Ingresos"]} />
                    <Bar dataKey="amount" fill="#8884d8" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="trends">
            <Card>
              <CardHeader>
                <CardTitle>Tendencias de Membresías</CardTitle>
                <CardDescription>Nuevas, renovadas y vencidas por día</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={reportData.membershipTrends}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Line type="monotone" dataKey="new" stroke="#00C49F" name="Nuevas" />
                    <Line type="monotone" dataKey="renewed" stroke="#0088FE" name="Renovadas" />
                    <Line type="monotone" dataKey="expired" stroke="#FF8042" name="Vencidas" />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </AuthGuard>
  )
}
