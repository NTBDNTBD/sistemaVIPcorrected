import { createClient } from '@supabase/supabase-js';
import { NextRequest, NextResponse } from 'next/server'
import { SecurityMiddleware } from '@/lib/security-middleware'
import { SecurityMonitor } from '@/lib/security-monitor' from '@/lib/security-middleware';

export async function POST(request: NextRequest) {
  const sec = SecurityMiddleware.getInstance()
  const secResp = await sec.checkSecurity(request, { rateLimitRequests: 10, rateLimitWindow: 60_000, allowedMethods: ['POST'] })
  if (secResp) return secResp

  const cookie = request.cookies.get('access_token')?.value
  if (!cookie) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  try {
    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
    const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

    if (!supabaseUrl || !supabaseServiceKey) {
      return NextResponse.json(
        { error: 'Supabase not configured' },
        { status: 503 }
      );
    }

    const operation = await request.json();
    const { type, table, data } = operation;

    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    let result;
    let error;

    switch (type) {
      case 'INSERT':
        ({ data: result, error } = await supabase.from(table).insert(data).select().single());
        break;
      case 'UPDATE':
        ({ data: result, error } = await supabase.from(table).update(data).eq('id', data.id).select().single());
        break;
      case 'DELETE':
        ({ error } = await supabase.from(table).delete().eq('id', data.id));
        result = { success: true };
        break;
      default:
        return NextResponse.json(
          { error: 'Invalid operation type' },
          { status: 400 }
        );
    }

    if (error) {
      console.error(`Sync operation failed:`, error);
      return NextResponse.json(
        { error: error.message },
        { status: 500 }
      );
    }

    return NextResponse.json({ success: true, data: result });
  } catch (error) {
    console.error('Sync operation error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}