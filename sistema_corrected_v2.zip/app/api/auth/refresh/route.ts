// app/api/auth/refresh/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { refreshAccessToken, getTokenFromCookies } from '@/lib/jwt-auth'
import { SecurityMonitor } from '@/lib/security-monitor'

const securityMonitor = new SecurityMonitor()

function getClientIP(request: NextRequest): string {
  return request.headers.get("cf-connecting-ip") || 
         request.headers.get("x-forwarded-for")?.split(",")[0].trim() ||
         request.headers.get("x-real-ip") || 
         "unknown"
}

export async function POST(request: NextRequest) {
  try {
    const clientIP = getClientIP(request)
    const userAgent = request.headers.get("user-agent") || ""
    
    // Obtener refresh token de las cookies
    const { refreshToken } = getTokenFromCookies()
    
    if (!refreshToken) {
      await securityMonitor.logSecurityEvent({
        type: "refresh_attempt_no_token",
        ip: clientIP,
        userAgent,
        details: { reason: "No refresh token provided" },
        severity: "low",
      })
      
      return NextResponse.json({ 
        error: 'No refresh token provided' 
      }, { status: 401 })
    }
    
    // Intentar refrescar el access token
    const newAccessToken = await refreshAccessToken(refreshToken)
    
    if (!newAccessToken) {
      await securityMonitor.logSecurityEvent({
        type: "refresh_token_failed",
        ip: clientIP,
        userAgent,
        details: { reason: "Token refresh failed" },
        severity: "medium",
      })
      
      // Clear cookies if refresh failed
      const response = NextResponse.json({ 
        error: 'Token refresh failed' 
      }, { status: 401 })
      
      response.cookies.set('access_token', '', {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'strict',
        maxAge: 0,
        path: '/'
      })
      
      response.cookies.set('refresh_token', '', {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'strict',
        maxAge: 0,
        path: '/'
      })
      
      return response
    }
    
    // Set new access token cookie
    const response = NextResponse.json({ 
      success: true,
      message: 'Token refreshed successfully'
    })
    
    response.cookies.set('access_token', newAccessToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      maxAge: 15 * 60, // 15 minutes
      path: '/'
    })
    
    // Log successful refresh (esto ya se hace en refreshAccessToken, pero confirmamos aquí)
    await securityMonitor.logSecurityEvent({
      type: "token_refresh_endpoint_success",
      ip: clientIP,
      userAgent,
      details: { message: "Access token refreshed via endpoint" },
      severity: "low",
    })
    
    return response
    
  } catch (error) {
    console.error('Refresh endpoint error:', error)
    
    const clientIP = getClientIP(request)
    const userAgent = request.headers.get("user-agent") || ""
    
    await securityMonitor.logSecurityEvent({
      type: "refresh_endpoint_error",
      ip: clientIP,
      userAgent,
      details: { 
        error: error instanceof Error ? error.message : 'Unknown error'
      },
      severity: "high",
    })
    
    return NextResponse.json({ 
      error: 'Internal server error' 
    }, { status: 500 })
  }
}