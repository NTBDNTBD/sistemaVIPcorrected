// app/api/auth/login/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'
import { createAccessToken, createRefreshToken, setAuthCookies } from '@/lib/jwt-auth'
import { storeRefreshToken, getUserData } from '@/lib/auth-database'
import { SecurityMonitor } from '@/lib/security-monitor'

const securityMonitor = new SecurityMonitor()

// Cliente de Supabase para autenticación
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
const supabase = createClient(supabaseUrl, supabaseAnonKey)

function getClientIP(request: NextRequest): string {
  return request.headers.get("cf-connecting-ip") || 
         request.headers.get("x-forwarded-for")?.split(",")[0].trim() ||
         request.headers.get("x-real-ip") || 
         "unknown"
}

export async function POST(request: NextRequest) {
  try {
    const { email, password } = await request.json()
    const clientIP = getClientIP(request)
    const userAgent = request.headers.get("user-agent") || ""

    // Validar que se proporcionaron email y password
    if (!email || !password) {
      return NextResponse.json({ 
        error: 'Email and password are required' 
      }, { status: 400 })
    }

    // Autenticar con Supabase
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password
    })
    
    if (error || !data.user) {
      await securityMonitor.logSecurityEvent({
        type: "login_failed",
        ip: clientIP,
        userAgent,
        details: { 
          email: email.toLowerCase(), 
          reason: error?.message || "invalid_credentials" 
        },
        severity: "medium",
      })
      
      return NextResponse.json({ 
        error: 'Invalid credentials' 
      }, { status: 401 })
    }
    
    const userId = data.user.id
    
    // Obtener datos actuales del usuario de tu sistema
    const userData = await getUserData(userId)
    if (!userData || !userData.isActive) {
      await securityMonitor.logSecurityEvent({
        type: "inactive_user_login_attempt",
        ip: clientIP,
        userAgent,
        details: { userId, email: email.toLowerCase() },
        severity: "medium",
      })
      
      return NextResponse.json({ 
        error: 'Account not active' 
      }, { status: 403 })
    }

    // Crear tokens JWT personalizados
    const accessToken = await createAccessToken({
      userId: userData.id,
      email: userData.email,
      role: userData.role,
      permissions: userData.permissions,
    })

    const refreshToken = await createRefreshToken(userId)
    
    // Calcular fecha de expiración del refresh token (7 días)
    const refreshExpiresAt = new Date()
    refreshExpiresAt.setDate(refreshExpiresAt.getDate() + 7)
    
    // Almacenar refresh token en la base de datos
    const tokenStored = await storeRefreshToken(
      userId, 
      refreshToken, 
      refreshExpiresAt,
      userAgent,
      clientIP
    )
    
    if (!tokenStored) {
      console.error('Failed to store refresh token')
      return NextResponse.json({ 
        error: 'Login failed - please try again' 
      }, { status: 500 })
    }

    // Establecer cookies
    setAuthCookies(accessToken, refreshToken)
    
    // Log successful login
    await securityMonitor.logSecurityEvent({
      type: "login_successful",
      ip: clientIP,
      userAgent,
      details: { 
        userId: userData.id, 
        email: userData.email,
        role: userData.role
      },
      severity: "low",
    })

    // Respuesta exitosa
    return NextResponse.json({
      success: true,
      user: {
        id: userData.id,
        email: userData.email,
        role: userData.role,
      }
    })

  } catch (error) {
    console.error('Login error:', error)
    
    const clientIP = getClientIP(request)
    const userAgent = request.headers.get("user-agent") || ""
    
    await securityMonitor.logSecurityEvent({
      type: "login_server_error",
      ip: clientIP,
      userAgent,
      details: { 
        error: error instanceof Error ? error.message : 'Unknown error' 
      },
      severity: "high",
    })
    
    return NextResponse.json({ 
      error: 'Internal server error' 
    }, { status: 500 })
  }
}