// app/api/auth/logout/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { clearAuthCookies, getTokenFromCookies } from '@/lib/jwt-auth'
import { revokeRefreshToken } from '@/lib/auth-database'
import { SecurityMonitor } from '@/lib/security-monitor'

const securityMonitor = new SecurityMonitor()

function getClientIP(request: NextRequest): string {
  return request.headers.get("cf-connecting-ip") || 
         request.headers.get("x-forwarded-for")?.split(",")[0].trim() ||
         request.headers.get("x-real-ip") || 
         "unknown"
}

export async function POST(request: NextRequest) {
  try {
    const clientIP = getClientIP(request)
    const userAgent = request.headers.get("user-agent") || ""
    
    // Obtener tokens actuales
    const { refreshToken } = getTokenFromCookies()
    
    let userId: string | null = null
    
    if (refreshToken) {
      // Decodificar el token para obtener el userId (sin verificar, solo para logging)
      try {
        const tokenParts = refreshToken.split('.')
        if (tokenParts.length === 3) {
          const payload = JSON.parse(atob(tokenParts[1]))
          userId = payload.userId || payload.sub
          
          // Revocar el refresh token específico en la base de datos
          const revoked = await revokeRefreshToken(userId, refreshToken)
          
          if (revoked) {
            console.log(`Refresh token revoked for user: ${userId}`)
          } else {
            console.warn(`Failed to revoke refresh token for user: ${userId}`)
          }
        }
      } catch (decodeError) {
        console.error('Error decoding refresh token during logout:', decodeError)
        // Continúa con el logout de todas formas
      }
    }
    
    // Limpiar cookies (siempre, incluso si no hay tokens)
    clearAuthCookies()
    
    // Log successful logout
    await securityMonitor.logSecurityEvent({
      type: "logout_successful",
      ip: clientIP,
      userAgent,
      details: { 
        userId: userId || 'unknown',
        hadRefreshToken: !!refreshToken
      },
      severity: "low",
    })
    
    return NextResponse.json({ 
      success: true,
      message: 'Logged out successfully'
    })
    
  } catch (error) {
    console.error('Logout error:', error)
    
    // Siempre limpiar cookies, incluso si hay error
    clearAuthCookies()
    
    const clientIP = getClientIP(request)
    const userAgent = request.headers.get("user-agent") || ""
    
    await securityMonitor.logSecurityEvent({
      type: "logout_error",
      ip: clientIP,
      userAgent,
      details: { 
        error: error instanceof Error ? error.message : 'Unknown error'
      },
      severity: "medium",
    })
    
    // Retorna éxito de todas formas - el logout debe funcionar siempre
    return NextResponse.json({ 
      success: true,
      message: 'Logged out (with errors)'
    })
  }
}