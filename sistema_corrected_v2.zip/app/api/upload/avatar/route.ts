import { type NextRequest, NextResponse } from "next/server"
import { fileUploadValidator } from "@/lib/file-upload-validator"
import { getCurrentUser } from "@/lib/auth"

export async function POST(request: NextRequest) {
  const sec = SecurityMiddleware.getInstance()
  const secResp = await sec.checkSecurity(request, { rateLimitRequests: 30, rateLimitWindow: 60_000, allowedMethods: ['POST'] })
  if (secResp) return secResp

  const cookie = request.cookies.get('access_token')?.value
  if (!cookie) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  // Parse form data
  const form = await request.formData().catch(() => null)
  if (!form) return NextResponse.json({ error: 'No form data' }, { status: 400 })
  const file = form.get('file') as any
  if (!file || typeof file.stream !== 'function') return NextResponse.json({ error: 'File missing' }, { status: 400 })

  const allowed = ['image/png','image/jpeg','image/jpg','application/pdf']
  const maxBytes = 10 * 1024 * 1024
  const fileSize = Number(file.size || 0)
  if (fileSize > maxBytes) return NextResponse.json({ error: 'File too large' }, { status: 413 })
  if (!allowed.includes(file.type)) return NextResponse.json({ error: 'Invalid file type' }, { status: 415 })

  // Store using supabase server helper
  try {
    const supabase = supabaseServer()
    const key = `uploads/${Date.now()}_${file.name.replace(/[^a-zA-Z0-9.\-_]/g, '_')}`
    const buf = Buffer.from(await file.arrayBuffer())
    const { data, error } = await supabase.storage.from('public').upload(key, buf, { contentType: file.type })
    if (error) return NextResponse.json({ error: 'Upload failed' }, { status: 500 })
    const publicUrl = supabase.storage.from('public').getPublicUrl(key).data?.publicUrl
    return NextResponse.json({ ok: true, url: publicUrl })
  } catch (e) {
    console.error('Upload error', e)
    return NextResponse.json({ error: 'Internal error' }, { status: 500 })
  }

  try {
    // Check authentication
    const user = await getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Authentication required" }, { status: 401 })
    }

    // Parse form data
    const formData = await request.formData()
    const file = formData.get("avatar") as File

    if (!file) {
      return NextResponse.json({ error: "No avatar file provided" }, { status: 400 })
    }

    // Convert to UploadedFile format
    const uploadedFile = {
      name: file.name,
      size: file.size,
      type: file.type,
      buffer: Buffer.from(await file.arrayBuffer()),
    }

    // Validate file
    const validation = fileUploadValidator.validateFile(uploadedFile)

    if (!validation.isValid) {
      return NextResponse.json(
        {
          error: "Avatar validation failed",
          details: validation.errors,
        },
        { status: 400 },
      )
    }

    // Additional avatar-specific validation
    if (file.size > 2 * 1024 * 1024) {
      // 2MB limit for avatars
      return NextResponse.json({ error: "Avatar file size must be less than 2MB" }, { status: 400 })
    }

    // Here you would upload to your storage service and update user profile
    const avatarUrl = `/uploads/avatars/${validation.sanitizedName}`

    return NextResponse.json({
      success: true,
      message: "Avatar uploaded successfully",
      avatarUrl,
    })
  } catch (error) {
    console.error("Avatar upload error:", error)
    return NextResponse.json({ error: "Internal server error during avatar upload" }, { status: 500 })
  }
}
