import { NextResponse } from "next/server"

export async function GET() {
  const securityTxt = `Contact: ${process.env.SECURITY_ALERT_EMAIL || "security@example.com"}
Expires: ${new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString()}
Encryption: https://keys.openpgp.org/
Preferred-Languages: es, en
Canonical: ${process.env.NEXT_PUBLIC_APP_URL || "https://example.com"}/.well-known/security.txt
Policy: ${process.env.NEXT_PUBLIC_APP_URL || "https://example.com"}/security-policy
Hiring: ${process.env.NEXT_PUBLIC_APP_URL || "https://example.com"}/careers

# Security Policy
# 
# We take security seriously. If you discover a security vulnerability,
# please report it to us as described below.
#
# Reporting Security Issues:
# - Email: ${process.env.SECURITY_ALERT_EMAIL || "security@example.com"}
# - Please include detailed steps to reproduce the issue
# - We will acknowledge receipt within 24 hours
# - We will provide a detailed response within 72 hours
#
# Scope:
# - This application and its subdomains
# - API endpoints
# - Authentication and authorization systems
# - Data handling and storage
#
# Out of Scope:
# - Social engineering attacks
# - Physical attacks
# - Denial of service attacks
# - Issues in third-party services
#
# Safe Harbor:
# We consider security research conducted under this policy to be:
# - Authorized in accordance with the law
# - Conducted in good faith
# - Not in violation of any applicable laws
`

  return new NextResponse(securityTxt, {
    headers: {
      "Content-Type": "text/plain",
      "Cache-Control": "public, max-age=86400",
    },
  })
}
