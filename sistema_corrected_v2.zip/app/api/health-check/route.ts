// app/api/health-check/route.ts
import { NextResponse } from 'next/server'
export async function GET() {
  return NextResponse.json({ status: 'ok' })
}
