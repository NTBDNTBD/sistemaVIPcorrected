import { type NextRequest, NextResponse } from "next/server"
import { getSupabaseClient, isDemo } from "@/lib/supabase"
import { sendSMS, sendWhatsApp, sendEmail } from "@/lib/twilio-server"
import { smsTemplates, whatsappTemplates, emailTemplates, type NotificationData } from "@/lib/notification-templates"
import { withSecurity } from "@/lib/security-middleware"

// Configuración del bar
const BAR_CONFIG = {
  name: process.env.NEXT_PUBLIC_BAR_NAME || "Bar VIP",
  contactPhone: process.env.NEXT_PUBLIC_CONTACT_PHONE || "+1234567890",
  renewalLink: process.env.NEXT_PUBLIC_RENEWAL_LINK || "https://barvip.com/renovar",
}

async function handlePost(request: NextRequest) {
  try {
    if (isDemo()) {
      console.log("[DEMO] Processing automatic notifications...")
      return NextResponse.json({
        success: true,
        message: "Demo mode - notifications simulated",
        timestamp: new Date().toISOString(),
      })
    }

    const supabase = getSupabaseClient()
    const today = new Date()

    // 1. Notificaciones de membresías por vencer (7 días antes)
    const warningDate = new Date(today.getTime() + 7 * 24 * 60 * 60 * 1000)
    const { data: expiringMembers } = await supabase
      .from("vip_members")
      .select("*")
      .eq("is_active", true)
      .lte("membership_end", warningDate.toISOString().split("T")[0])
      .gte("membership_end", today.toISOString().split("T")[0])

    if (expiringMembers) {
      for (const member of expiringMembers) {
        const daysLeft = Math.ceil(
          (new Date(member.membership_end).getTime() - today.getTime()) / (1000 * 60 * 60 * 24),
        )

        const notificationData: NotificationData = {
          memberName: member.full_name,
          memberCode: member.member_code,
          barName: BAR_CONFIG.name,
          contactPhone: BAR_CONFIG.contactPhone,
          renewalLink: BAR_CONFIG.renewalLink,
          daysLeft,
        }

        // Enviar notificaciones
        try {
          await sendSMS(member.phone, smsTemplates.expiring(notificationData))
          await sendWhatsApp(member.phone, whatsappTemplates.expiring(notificationData))
          const emailTemplate = emailTemplates.expiring(notificationData)
          await sendEmail(member.email, emailTemplate.subject, emailTemplate.html, emailTemplate.text)
        } catch (error) {
          console.error(`Error sending notifications to ${member.full_name}:`, error)
        }
      }
    }

    // 2. Notificaciones de membresías vencidas
    const expiredStartDate = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000)
    const { data: expiredMembers } = await supabase
      .from("vip_members")
      .select("*")
      .lt("membership_end", today.toISOString().split("T")[0])
      .gte("membership_end", expiredStartDate.toISOString().split("T")[0])

    if (expiredMembers) {
      for (const member of expiredMembers) {
        const daysExpired = Math.ceil(
          (today.getTime() - new Date(member.membership_end).getTime()) / (1000 * 60 * 60 * 24),
        )

        const notificationData: NotificationData = {
          memberName: member.full_name,
          memberCode: member.member_code,
          barName: BAR_CONFIG.name,
          contactPhone: BAR_CONFIG.contactPhone,
          renewalLink: BAR_CONFIG.renewalLink,
          daysExpired,
        }

        // Enviar notificaciones
        try {
          await sendSMS(member.phone, smsTemplates.expired(notificationData))
          await sendWhatsApp(member.phone, whatsappTemplates.expired(notificationData))
          const emailTemplate = emailTemplates.expired(notificationData)
          await sendEmail(member.email, emailTemplate.subject, emailTemplate.html, emailTemplate.text)
        } catch (error) {
          console.error(`Error sending notifications to ${member.full_name}:`, error)
        }

        // Desactivar membresía si no está ya desactivada
        if (member.is_active) {
          await supabase.from("vip_members").update({ is_active: false }).eq("id", member.id)
        }
      }
    }

    return NextResponse.json({
      success: true,
      message: "Automatic notifications processed successfully",
      timestamp: new Date().toISOString(),
    })
  } catch (error: any) {
    console.error("Error processing notifications:", error)
    return NextResponse.json(
      {
        success: false,
        error: error.message,
        timestamp: new Date().toISOString(),
      },
      { status: 500 },
    )
  }
}

async function handleGet() {
  return NextResponse.json({
    status: "active",
    service: "notification-processor",
    timestamp: new Date().toISOString(),
  })
}

export async function POST(request: NextRequest) {
  const sec = SecurityMiddleware.getInstance()
  const secResp = await sec.checkSecurity(request, { rateLimitRequests: 20, rateLimitWindow: 60_000, allowedMethods: ['POST'] })
  if (secResp) return secResp

  // Require admin or operador role
  const cookie = request.cookies.get('access_token')?.value
  if (!cookie) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  return withSecurity(request, handlePost, {
    requireAuth: true,
    requireRole: ["administrador", "manager"],
    rateLimitRequests: 10,
    rateLimitWindow: 60000, // 1 minute
    requireCSRF: true,
    allowedMethods: ["POST"],
  })
}

export async function GET(request: NextRequest) {
  return withSecurity(request, handleGet, {
    requireAuth: true,
    rateLimitRequests: 30,
    rateLimitWindow: 60000,
    allowedMethods: ["GET"],
  })
}
