import { type NextRequest, NextResponse } from "next/server"
import { withSecurity } from "@/lib/security-middleware"

// API endpoint para probar las configuraciones de notificación
export async function POST(request: NextRequest) {
  const sec = SecurityMiddleware.getInstance()
  const secResp = await sec.checkSecurity(request, { rateLimitRequests: 20, rateLimitWindow: 60_000, allowedMethods: ['POST'] })
  if (secResp) return secResp

  // Require admin or operador role
  const cookie = request.cookies.get('access_token')?.value
  if (!cookie) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  return withSecurity(request, handlePost, {
    requireAuth: true,
    requireRole: ["administrador"],
    rateLimitRequests: 5,
    rateLimitWindow: 300000, // 5 minutes
    requireCSRF: true,
    allowedMethods: ["POST"],
  })
}

async function handlePost(request: NextRequest) {
  try {
    const body = await request.json()
    const { twilioAccountSid, twilioAuthToken, sendgridApiKey } = body

    const results = {
      twilio: false,
      sendgrid: false,
      errors: [] as string[],
    }

    // Probar Twilio
    if (twilioAccountSid && twilioAuthToken) {
      try {
        if (typeof require !== "undefined") {
          const twilio = require("twilio")
          const client = twilio(twilioAccountSid, twilioAuthToken)
          await client.api.accounts(twilioAccountSid).fetch()
          results.twilio = true
        } else {
          results.errors.push("Twilio: Módulo no disponible en este entorno")
        }
      } catch (error: any) {
        results.errors.push(`Twilio: ${error.message}`)
      }
    } else {
      results.errors.push("Twilio: Credenciales faltantes")
    }

    // Probar SendGrid
    if (sendgridApiKey) {
      try {
        results.errors.push("SendGrid: Funcionalidad temporalmente deshabilitada")
      } catch (error: any) {
        results.errors.push(`SendGrid: ${error.message}`)
      }
    } else {
      results.errors.push("SendGrid: API Key faltante")
    }

    return NextResponse.json({
      success: results.twilio && results.sendgrid,
      results,
      timestamp: new Date().toISOString(),
    })
  } catch (error: any) {
    console.error("Error testing notifications:", error)
    return NextResponse.json(
      {
        success: false,
        error: error.message,
        timestamp: new Date().toISOString(),
      },
      { status: 500 },
    )
  }
}
