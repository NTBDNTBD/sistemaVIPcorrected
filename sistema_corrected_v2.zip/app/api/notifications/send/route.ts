import { type NextRequest, NextResponse } from "next/server"
import { getSupabaseClient, isDemo } from "@/lib/supabase"
import { sendSMS, sendWhatsApp, sendEmail } from "@/lib/twilio-server"
import { smsTemplates, whatsappTemplates, emailTemplates, type NotificationData } from "@/lib/notification-templates"
import { withRBAC } from "@/lib/rbac-middleware"

// Configuración del bar
const BAR_CONFIG = {
  name: process.env.NEXT_PUBLIC_BAR_NAME || "Bar VIP",
  contactPhone: process.env.NEXT_PUBLIC_CONTACT_PHONE || "+1234567890",
  renewalLink: process.env.NEXT_PUBLIC_RENEWAL_LINK || "https://barvip.com/renovar",
}

export async function POST(request: NextRequest) {
  const sec = SecurityMiddleware.getInstance()
  const secResp = await sec.checkSecurity(request, { rateLimitRequests: 20, rateLimitWindow: 60_000, allowedMethods: ['POST'] })
  if (secResp) return secResp

  // Require admin or operador role
  const cookie = request.cookies.get('access_token')?.value
  if (!cookie) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  return withRBAC(request, handlePost, {
    requiredPermissions: ["manage_notifications"],
    allowDemo: true,
  })
}

async function handlePost(request: NextRequest) {
  try {
    const body = await request.json()
    const { memberId, type, additionalData } = body

    if (!memberId || !type) {
      return NextResponse.json({ error: "memberId and type are required" }, { status: 400 })
    }

    // Obtener datos del miembro
    let member
    if (isDemo()) {
      member = {
        id: memberId,
        full_name: "Usuario Demo",
        email: "demo@barvip.com",
        phone: "+1234567890",
        member_code: "VIP123456",
      }
    } else {
      const supabase = getSupabaseClient()
      const { data, error } = await supabase.from("vip_members").select("*").eq("id", memberId).single()

      if (error || !data) {
        return NextResponse.json({ error: "Member not found" }, { status: 404 })
      }
      member = data
    }

    // Preparar datos para las plantillas
    const notificationData: NotificationData = {
      memberName: member.full_name,
      memberCode: member.member_code,
      barName: BAR_CONFIG.name,
      contactPhone: BAR_CONFIG.contactPhone,
      renewalLink: BAR_CONFIG.renewalLink,
      ...additionalData,
    }

    const results = []

    // Enviar SMS
    try {
      const message = smsTemplates[type](notificationData)
      const result = await sendSMS(member.phone, message)
      results.push({ channel: "sms", ...result })
    } catch (error) {
      results.push({ channel: "sms", success: false, error: error.message })
    }

    // Enviar WhatsApp
    try {
      const message = whatsappTemplates[type](notificationData)
      const result = await sendWhatsApp(member.phone, message)
      results.push({ channel: "whatsapp", ...result })
    } catch (error) {
      results.push({ channel: "whatsapp", success: false, error: error.message })
    }

    // Enviar Email
    try {
      const emailTemplate = emailTemplates[type](notificationData)
      const result = await sendEmail(member.email, emailTemplate.subject, emailTemplate.html, emailTemplate.text)
      results.push({ channel: "email", ...result })
    } catch (error) {
      results.push({ channel: "email", success: false, error: error.message })
    }

    return NextResponse.json({
      success: true,
      result: results,
      timestamp: new Date().toISOString(),
    })
  } catch (error: any) {
    console.error("Error sending notification:", error)
    return NextResponse.json(
      {
        success: false,
        error: error.message,
        timestamp: new Date().toISOString(),
      },
      { status: 500 },
    )
  }
}
