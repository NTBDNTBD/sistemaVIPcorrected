"use client"

import { useEffect, useState } from "react"
import { getSupabaseClient, isDemo } from "@/lib/supabase"
import { AuthGuard } from "@/components/auth-guard"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Bell, MessageSquare, Mail, Smartphone, Send, Settings, Activity } from "lucide-react"

interface NotificationLog {
  id: string
  member_id: string
  notification_type: string
  channel: string
  status: string
  message: string
  sent_at: string
  vip_members?: {
    full_name: string
    member_code: string
  }
}

const demoNotificationLogs = [
  {
    id: "log-1",
    member_id: "demo-member-1",
    notification_type: "welcome",
    channel: "email",
    status: "sent",
    message: "¡Bienvenido al Bar VIP!",
    sent_at: "2024-01-10T10:00:00Z",
    vip_members: { full_name: "Juan Pérez", member_code: "VIP123456ABCD" },
  },
  {
    id: "log-2",
    member_id: "demo-member-2",
    notification_type: "expiring",
    channel: "whatsapp",
    status: "sent",
    message: "Tu membresía expira en 5 días",
    sent_at: "2024-01-10T14:30:00Z",
    vip_members: { full_name: "María García", member_code: "VIP789012EFGH" },
  },
]

export default function NotificationsPage() {
  const [logs, setLogs] = useState<NotificationLog[]>([])
  const [stats, setStats] = useState({
    totalSent: 0,
    totalFailed: 0,
    smsCount: 0,
    whatsappCount: 0,
    emailCount: 0,
  })
  const [loading, setLoading] = useState(true)
  const [processing, setProcessing] = useState(false)

  useEffect(() => {
    loadNotificationLogs()
  }, [])

  const loadNotificationLogs = async () => {
    try {
      if (isDemo()) {
        setLogs(demoNotificationLogs)
        setStats({
          totalSent: 2,
          totalFailed: 0,
          smsCount: 0,
          whatsappCount: 1,
          emailCount: 1,
        })
        setLoading(false)
        return
      }

      const supabase = getSupabaseClient()
      const { data, error } = await supabase
        .from("notification_logs")
        .select(
          `
          *,
          vip_members (
            full_name,
            member_code
          )
        `,
        )
        .order("sent_at", { ascending: false })
        .limit(100)

      if (error) throw error

      setLogs(data || [])

      // Calcular estadísticas
      const totalSent = data?.filter((log) => log.status === "sent").length || 0
      const totalFailed = data?.filter((log) => log.status === "failed").length || 0
      const smsCount = data?.filter((log) => log.channel === "sms").length || 0
      const whatsappCount = data?.filter((log) => log.channel === "whatsapp").length || 0
      const emailCount = data?.filter((log) => log.channel === "email").length || 0

      setStats({ totalSent, totalFailed, smsCount, whatsappCount, emailCount })
    } catch (error) {
      console.error("Error loading notification logs:", error)
      setLogs(demoNotificationLogs)
    } finally {
      setLoading(false)
    }
  }

  const processNotifications = async () => {
    setProcessing(true)
    try {
      const response = await fetch("/api/notifications/process", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
      })

      if (!response.ok) {
        throw new Error("Failed to process notifications")
      }

      await loadNotificationLogs()
    } catch (error) {
      console.error("Error processing notifications:", error)
    } finally {
      setProcessing(false)
    }
  }

  const getChannelIcon = (channel: string) => {
    switch (channel) {
      case "sms":
        return <MessageSquare className="h-4 w-4" />
      case "whatsapp":
        return <Smartphone className="h-4 w-4" />
      case "email":
        return <Mail className="h-4 w-4" />
      default:
        return <Bell className="h-4 w-4" />
    }
  }

  const getTypeLabel = (type: string) => {
    switch (type) {
      case "welcome":
        return "Bienvenida"
      case "expiring":
        return "Por Vencer"
      case "expired":
        return "Vencida"
      case "renewed":
        return "Renovada"
      default:
        return type
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "sent":
        return <Badge variant="default">Enviado</Badge>
      case "failed":
        return <Badge variant="destructive">Fallido</Badge>
      case "demo":
        return <Badge variant="secondary">Demo</Badge>
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  if (loading) {
    return (
      <AuthGuard requiredPermissions={["manage_members"]}>
        <div className="flex items-center justify-center min-h-screen">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </div>
      </AuthGuard>
    )
  }

  return (
    <AuthGuard requiredPermissions={["manage_members"]}>
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Sistema de Notificaciones</h1>
            <p className="text-muted-foreground">
              Gestiona las notificaciones automáticas por SMS, WhatsApp y Email
              {isDemo() && <span className="ml-2 text-orange-500">(Modo Demo)</span>}
            </p>
          </div>
          <Button onClick={processNotifications} disabled={processing}>
            {processing ? <Activity className="mr-2 h-4 w-4 animate-spin" /> : <Send className="mr-2 h-4 w-4" />}
            Procesar Notificaciones
          </Button>
        </div>

        {isDemo() && (
          <Alert>
            <Settings className="h-4 w-4" />
            <AlertDescription>
              En modo demo, las notificaciones se simulan. Para usar Twilio real, configura las variables de entorno:
              TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, SENDGRID_API_KEY
            </AlertDescription>
          </Alert>
        )}

        {/* Estadísticas */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-5">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Enviadas</CardTitle>
              <Send className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">{stats.totalSent}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Fallidas</CardTitle>
              <Bell className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-600">{stats.totalFailed}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">SMS</CardTitle>
              <MessageSquare className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.smsCount}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">WhatsApp</CardTitle>
              <Smartphone className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.whatsappCount}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Email</CardTitle>
              <Mail className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.emailCount}</div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="logs" className="space-y-4">
          <TabsList>
            <TabsTrigger value="logs">Historial de Notificaciones</TabsTrigger>
            <TabsTrigger value="settings">Configuración</TabsTrigger>
          </TabsList>

          <TabsContent value="logs">
            <Card>
              <CardHeader>
                <CardTitle>Historial de Notificaciones</CardTitle>
                <CardDescription>Últimas {logs.length} notificaciones enviadas</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Miembro</TableHead>
                      <TableHead>Tipo</TableHead>
                      <TableHead>Canal</TableHead>
                      <TableHead>Estado</TableHead>
                      <TableHead>Mensaje</TableHead>
                      <TableHead>Fecha</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {logs.map((log) => (
                      <TableRow key={log.id}>
                        <TableCell>
                          <div>
                            <div className="font-medium">{log.vip_members?.full_name}</div>
                            <div className="text-sm text-muted-foreground font-mono">
                              {log.vip_members?.member_code}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline">{getTypeLabel(log.notification_type)}</Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-2">
                            {getChannelIcon(log.channel)}
                            <span className="capitalize">{log.channel}</span>
                          </div>
                        </TableCell>
                        <TableCell>{getStatusBadge(log.status)}</TableCell>
                        <TableCell className="max-w-xs truncate">{log.message}</TableCell>
                        <TableCell>{new Date(log.sent_at).toLocaleString()}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings">
            <div className="grid gap-4 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Configuración de Canales</CardTitle>
                  <CardDescription>Configurar proveedores de notificaciones</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <MessageSquare className="h-4 w-4" />
                      <span>SMS (Twilio)</span>
                    </div>
                    <Badge variant={isDemo() ? "secondary" : "default"}>{isDemo() ? "Demo" : "Configurado"}</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Smartphone className="h-4 w-4" />
                      <span>WhatsApp (Twilio)</span>
                    </div>
                    <Badge variant={isDemo() ? "secondary" : "default"}>{isDemo() ? "Demo" : "Configurado"}</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Mail className="h-4 w-4" />
                      <span>Email (SendGrid)</span>
                    </div>
                    <Badge variant={isDemo() ? "secondary" : "default"}>{isDemo() ? "Demo" : "Configurado"}</Badge>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Configuración de Tiempos</CardTitle>
                  <CardDescription>Configurar cuándo enviar notificaciones</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between">
                    <span>Notificar antes de expirar:</span>
                    <Badge variant="outline">7 días</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>Notificar después de expirar:</span>
                    <Badge variant="outline">7 días</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>Bienvenida (retraso):</span>
                    <Badge variant="outline">5 minutos</Badge>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </AuthGuard>
  )
}
