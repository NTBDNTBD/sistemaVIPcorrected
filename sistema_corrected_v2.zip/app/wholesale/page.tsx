import WholesaleManager from "@/components/wholesale-manager"

export default function WholesalePage() {
  return <WholesaleManager />
}
