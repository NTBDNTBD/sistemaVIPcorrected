"use client"

import { useEffect, useState } from "react"
import { getSupabaseClient, isDemo } from "@/lib/supabase"
import { AuthGuard } from "@/components/auth-guard"
import { QRScanner } from "@/components/qr-scanner"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/hooks/use-toast"
import { LocalStorageBackup } from "@/lib/local-storage-backup"
import {
  ShoppingCart,
  CreditCard,
  Smartphone,
  Banknote,
  Plus,
  Minus,
  Trash2,
  QrCode,
  Calculator,
  Receipt,
  Scan,
  Star,
  Clock,
} from "lucide-react"

interface Product {
  id: string
  name: string
  price: number
  category: string
  loyalty_points_earned: number
  points_per_dollar: number
  qr_code: string
  stock_quantity: number
  is_featured: boolean
  preparation_time: number
  description?: string
}

interface CartItem extends Product {
  quantity: number
  subtotal: number
}

interface Member {
  id: string
  member_code: string
  full_name: string
  loyalty_points: number
  is_active: boolean
  total_spent?: number
}

const demoProducts: Product[] = [
  {
    id: "prod-1",
    name: "Whisky Premium",
    price: 150.0,
    category: "Bebidas Premium",
    loyalty_points_earned: 15,
    points_per_dollar: 0.1,
    qr_code: "PRD123456",
    stock_quantity: 25,
    is_featured: true,
    preparation_time: 2,
    description: "Whisky de 18 años",
  },
  {
    id: "prod-2",
    name: "Cocktail Signature",
    price: 80.0,
    category: "Bebidas Premium",
    loyalty_points_earned: 8,
    points_per_dollar: 0.1,
    qr_code: "PRD789012",
    stock_quantity: 50,
    is_featured: false,
    preparation_time: 5,
    description: "Cocktail exclusivo de la casa",
  },
  {
    id: "prod-3",
    name: "Tabla de Quesos Gourmet",
    price: 120.0,
    category: "Aperitivos Gourmet",
    loyalty_points_earned: 12,
    points_per_dollar: 0.1,
    qr_code: "PRD345678",
    stock_quantity: 15,
    is_featured: true,
    preparation_time: 8,
    description: "Selección de quesos importados",
  },
]

export default function POSPage() {
  const [products, setProducts] = useState<Product[]>(demoProducts)
  const [cart, setCart] = useState<CartItem[]>([])
  const [member, setMember] = useState<Member | null>(null)
  const [memberCode, setMemberCode] = useState("")
  const [paymentMethod, setPaymentMethod] = useState<"cash" | "card" | "digital">("card")
  const [loading, setLoading] = useState(false)
  const [processing, setProcessing] = useState(false)
  const [scannerActive, setScannerActive] = useState(false)
  const [loyaltyConfig, setLoyaltyConfig] = useState({ points_per_dollar: 0.1, bonus_multiplier: 1.0 })
  const { toast } = useToast()

  useEffect(() => {
    loadProducts()
    loadLoyaltyConfig()
  }, [])

  const loadProducts = async () => {
    try {
      if (isDemo()) {
        setProducts(demoProducts)
        return
      }

      const supabase = getSupabaseClient()
      const { data, error } = await supabase
        .from("products")
        .select(`
          id,
          name,
          price,
          description,
          category,
          qr_code,
          stock,
          wholesale_price,
          cost,
          min_stock,
          is_active
        `)
        .eq("is_active", true)

      if (error) throw error

      const formattedProducts =
        data?.map((p) => ({
          id: p.id,
          name: p.name,
          price: p.price,
          category: p.category || "Sin categoría",
          loyalty_points_earned: Math.floor(p.price * 0.1),
          points_per_dollar: 0.1,
          qr_code: p.qr_code || `PRD${p.id.slice(0, 6)}`,
          stock_quantity: p.stock || 0,
          is_featured: p.price > 100,
          preparation_time: 5,
          description: p.description,
        })) || []

      setProducts(formattedProducts)
    } catch (error) {
      console.error("Error loading products:", error)
      setProducts(demoProducts)
      toast({
        title: "Modo Demo Activo",
        description: "Usando productos de demostración",
      })
    }
  }

  const loadLoyaltyConfig = async () => {
    try {
      if (isDemo()) return

      const supabase = getSupabaseClient()
      const { data, error } = await supabase.from("loyalty_config").select("*").eq("is_active", true).single()

      // If table doesn't exist or no data found, use defaults
      if (error || !data) {
        console.log("Using default loyalty configuration")
        return
      }

      setLoyaltyConfig({
        points_per_dollar: data.points_per_dollar,
        bonus_multiplier: data.bonus_multiplier,
      })
    } catch (error) {
      console.log("Loyalty config table not found, using defaults:", error)
      // Keep default values: { points_per_dollar: 0.1, bonus_multiplier: 1.0 }
    }
  }

  const searchMember = async () => {
    if (!memberCode.trim()) return

    setLoading(true)
    try {
      if (isDemo()) {
        const demoMember = {
          id: "demo-member-1",
          member_code: memberCode,
          full_name: "Juan Pérez",
          loyalty_points: 125,
          is_active: true,
        }
        setMember(demoMember)
        toast({
          title: "Miembro Encontrado",
          description: `${demoMember.full_name} - ${demoMember.loyalty_points} puntos`,
        })
        setLoading(false)
        return
      }

      const supabase = getSupabaseClient()
      const { data, error } = await supabase
        .from("vip_members")
        .select("id, member_code, full_name, loyalty_points, is_active, total_spent")
        .eq("member_code", memberCode.trim())
        .single()

      if (error || !data) {
        toast({
          title: "Miembro No Encontrado",
          description: "Verifica el código del miembro",
          variant: "destructive",
        })
        setMember(null)
        return
      }

      if (!data.is_active) {
        toast({
          title: "Membresía Inactiva",
          description: "La membresía de este miembro ha expirado",
          variant: "destructive",
        })
        setMember(null)
        return
      }

      setMember(data)
      toast({
        title: "Miembro Encontrado",
        description: `${data.full_name} - ${data.loyalty_points} puntos`,
      })
    } catch (error) {
      console.error("Error searching member:", error)
      toast({
        title: "Error",
        description: "No se pudo buscar el miembro",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const handleQRScan = (qrData: string) => {
    try {
      let productData
      try {
        productData = JSON.parse(qrData)
      } catch {
        // If not JSON, treat as simple product code
        productData = { productCode: qrData, type: "product" }
      }

      if (!productData || productData.type !== "product") {
        toast({
          title: "QR Inválido",
          description: "El código QR no corresponde a un producto válido",
          variant: "destructive",
        })
        return
      }

      const product = products.find(
        (p) =>
          p.qr_code === qrData ||
          p.qr_code === productData.productCode ||
          p.id === productData.productId ||
          p.name.toLowerCase().includes(productData.name?.toLowerCase() || ""),
      )

      if (!product) {
        toast({
          title: "Producto No Encontrado",
          description: `Producto no encontrado en el inventario`,
          variant: "destructive",
        })
        return
      }

      if (product.stock_quantity <= 0) {
        toast({
          title: "Sin Stock",
          description: `${product.name} no tiene stock disponible`,
          variant: "destructive",
        })
        return
      }

      addToCart(product)
      toast({
        title: "Producto Agregado",
        description: `${product.name} agregado al carrito`,
      })

      setScannerActive(false)
    } catch (error) {
      console.error("QR scan error:", error)
      toast({
        title: "Error de Escaneo",
        description: "No se pudo procesar el código QR",
        variant: "destructive",
      })
    }
  }

  const addToCart = (product: Product) => {
    const existingItem = cart.find((item) => item.id === product.id)

    if (existingItem) {
      if (existingItem.quantity >= product.stock_quantity) {
        toast({
          title: "Stock Insuficiente",
          description: `Solo hay ${product.stock_quantity} unidades disponibles`,
          variant: "destructive",
        })
        return
      }

      setCart(
        cart.map((item) =>
          item.id === product.id
            ? { ...item, quantity: item.quantity + 1, subtotal: (item.quantity + 1) * item.price }
            : item,
        ),
      )
    } else {
      setCart([...cart, { ...product, quantity: 1, subtotal: product.price }])
    }
  }

  const updateQuantity = (productId: string, newQuantity: number) => {
    if (newQuantity <= 0) {
      removeFromCart(productId)
      return
    }

    const product = products.find((p) => p.id === productId)
    if (product && newQuantity > product.stock_quantity) {
      toast({
        title: "Stock Insuficiente",
        description: `Solo hay ${product.stock_quantity} unidades disponibles`,
        variant: "destructive",
      })
      return
    }

    setCart(
      cart.map((item) =>
        item.id === productId ? { ...item, quantity: newQuantity, subtotal: newQuantity * item.price } : item,
      ),
    )
  }

  const removeFromCart = (productId: string) => {
    setCart(cart.filter((item) => item.id !== productId))
  }

  const clearCart = () => {
    setCart([])
    setMember(null)
    setMemberCode("")
  }

  const calculateTotal = () => {
    return cart.reduce((sum, item) => sum + item.subtotal, 0)
  }

  const calculateLoyaltyPoints = () => {
    const basePoints = cart.reduce((sum, item) => {
      const productPoints = item.price * item.points_per_dollar * item.quantity
      return sum + productPoints
    }, 0)

    return Math.floor(basePoints * loyaltyConfig.bonus_multiplier)
  }

  const getTotalPreparationTime = () => {
    return cart.reduce((sum, item) => sum + item.preparation_time * item.quantity, 0)
  }

  const processPayment = async () => {
    if (cart.length === 0) {
      toast({
        title: "Carrito Vacío",
        description: "Agrega productos antes de procesar el pago",
        variant: "destructive",
      })
      return
    }

    setProcessing(true)
    try {
      const total = calculateTotal()
      const loyaltyPoints = calculateLoyaltyPoints()
      const transactionCode = `TXN${Date.now()}`

      if (isDemo()) {
        await new Promise((resolve) => setTimeout(resolve, 2000))

        if (member) {
          const newLoyaltyPoints = member.loyalty_points + loyaltyPoints
          const newTotalSpent = (member.total_spent || 0) + total

          LocalStorageBackup.backupMember(member.id, newLoyaltyPoints, newTotalSpent)

          setMember({
            ...member,
            loyalty_points: newLoyaltyPoints,
            total_spent: newTotalSpent,
          })
        }

        LocalStorageBackup.backupTransaction({
          id: transactionCode,
          member_id: member?.id || "",
          total_amount: total,
          loyalty_points_earned: loyaltyPoints,
          timestamp: new Date().toISOString(),
          synced: false,
        })

        toast({
          title: "Pago Procesado",
          description: `Transacción ${transactionCode} completada por $${total.toFixed(2)}`,
        })

        clearCart()
        setProcessing(false)
        return
      }

      const supabase = getSupabaseClient()

      try {
        // Crear transacción
        const { data: transaction, error: transactionError } = await supabase
          .from("transactions")
          .insert({
            transaction_code: transactionCode,
            member_id: member?.id,
            total_amount: total,
            payment_method: paymentMethod,
            payment_status: "completed",
            loyalty_points_earned: loyaltyPoints,
          })
          .select()
          .single()

        if (transactionError) throw transactionError

        // Crear detalles de transacción
        const transactionDetails = cart.map((item) => ({
          transaction_id: transaction.id,
          product_id: item.id,
          quantity: item.quantity,
          unit_price: item.price,
          subtotal: item.subtotal,
        }))

        const { error: detailsError } = await supabase.from("transaction_details").insert(transactionDetails)

        if (detailsError) throw detailsError

        // Actualizar stock de productos
        for (const item of cart) {
          await supabase
            .from("products")
            .update({ stock: item.stock_quantity - item.quantity })
            .eq("id", item.id)
        }

        // Actualizar puntos del miembro si existe
        if (member) {
          const newLoyaltyPoints = member.loyalty_points + loyaltyPoints
          const newTotalSpent = (member.total_spent || 0) + total

          const { error: memberError } = await supabase
            .from("vip_members")
            .update({
              loyalty_points: newLoyaltyPoints,
              total_spent: newTotalSpent,
            })
            .eq("id", member.id)

          if (memberError) throw memberError

          setMember({
            ...member,
            loyalty_points: newLoyaltyPoints,
            total_spent: newTotalSpent,
          })
        }

        toast({
          title: "Pago Procesado",
          description: `Transacción ${transactionCode} completada exitosamente`,
        })

        clearCart()
      } catch (supabaseError) {
        console.error("Supabase error, falling back to localStorage:", supabaseError)

        if (member) {
          const newLoyaltyPoints = member.loyalty_points + loyaltyPoints
          const newTotalSpent = (member.total_spent || 0) + total

          LocalStorageBackup.backupMember(member.id, newLoyaltyPoints, newTotalSpent)

          setMember({
            ...member,
            loyalty_points: newLoyaltyPoints,
            total_spent: newTotalSpent,
          })
        }

        LocalStorageBackup.backupTransaction({
          id: transactionCode,
          member_id: member?.id || "",
          total_amount: total,
          loyalty_points_earned: loyaltyPoints,
          timestamp: new Date().toISOString(),
          synced: false,
        })

        toast({
          title: "Pago Procesado (Modo Offline)",
          description: `Transacción guardada localmente. Se sincronizará cuando vuelva la conexión.`,
        })

        clearCart()
      }
    } catch (error) {
      console.error("Error processing payment:", error)
      toast({
        title: "Error en el Pago",
        description: "No se pudo procesar la transacción",
        variant: "destructive",
      })
    } finally {
      setProcessing(false)
    }
  }

  const getPaymentIcon = (method: string) => {
    switch (method) {
      case "card":
        return <CreditCard className="h-4 w-4" />
      case "digital":
        return <Smartphone className="h-4 w-4" />
      case "cash":
        return <Banknote className="h-4 w-4" />
      default:
        return <CreditCard className="h-4 w-4" />
    }
  }

  const featuredProducts = products.filter((p) => p.is_featured)
  const regularProducts = products.filter((p) => !p.is_featured)

  return (
    <AuthGuard requiredPermissions={["process_payments"]}>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Sistema POS con Escáner QR</h1>
          <p className="text-muted-foreground">
            Punto de venta con escáner de códigos QR para productos
            {isDemo() && (
              <Badge variant="outline" className="ml-2">
                Modo Demo
              </Badge>
            )}
          </p>
        </div>

        <div className="grid gap-6 lg:grid-cols-4">
          {/* Panel de Productos y Escáner */}
          <div className="lg:col-span-3">
            <Tabs defaultValue="products" className="space-y-4">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="products">Productos</TabsTrigger>
                <TabsTrigger value="scanner">
                  <Scan className="mr-2 h-4 w-4" />
                  Escáner QR
                </TabsTrigger>
                <TabsTrigger value="featured">
                  <Star className="mr-2 h-4 w-4" />
                  Destacados
                </TabsTrigger>
              </TabsList>

              <TabsContent value="products">
                <Card>
                  <CardHeader>
                    <CardTitle>Catálogo de Productos</CardTitle>
                    <CardDescription>Selecciona productos para agregar al carrito</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                      {regularProducts.map((product) => (
                        <Card key={product.id} className="cursor-pointer hover:shadow-md transition-shadow">
                          <CardContent className="p-4">
                            <div className="space-y-2">
                              <div className="flex justify-between items-start">
                                <h3 className="font-semibold text-sm">{product.name}</h3>
                                {product.preparation_time > 0 && (
                                  <Badge variant="outline" className="text-xs">
                                    <Clock className="mr-1 h-3 w-3" />
                                    {product.preparation_time}min
                                  </Badge>
                                )}
                              </div>
                              <p className="text-xs text-muted-foreground">{product.description}</p>
                              <p className="text-xs text-muted-foreground">{product.category}</p>
                              <div className="flex justify-between items-center">
                                <span className="text-lg font-bold">${product.price.toFixed(2)}</span>
                                <Badge variant="outline">
                                  {Math.floor(product.price * product.points_per_dollar)} pts
                                </Badge>
                              </div>
                              <div className="flex justify-between items-center">
                                <Badge variant={product.stock_quantity > 10 ? "default" : "destructive"}>
                                  Stock: {product.stock_quantity}
                                </Badge>
                                <Button
                                  onClick={() => addToCart(product)}
                                  className="w-full"
                                  size="sm"
                                  disabled={product.stock_quantity <= 0}
                                >
                                  <Plus className="mr-2 h-4 w-4" />
                                  Agregar
                                </Button>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="scanner">
                <div className="flex justify-center">
                  <QRScanner
                    onScan={handleQRScan}
                    onError={(error) =>
                      toast({
                        title: "Error de Escáner",
                        description: error,
                        variant: "destructive",
                      })
                    }
                    isActive={scannerActive}
                    onToggle={() => setScannerActive(!scannerActive)}
                  />
                </div>
              </TabsContent>

              <TabsContent value="featured">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Star className="mr-2 h-5 w-5 text-yellow-500" />
                      Productos Destacados
                    </CardTitle>
                    <CardDescription>Productos más populares y promocionados</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                      {featuredProducts.map((product) => (
                        <Card
                          key={product.id}
                          className="cursor-pointer hover:shadow-md transition-shadow border-yellow-200"
                        >
                          <CardContent className="p-4">
                            <div className="space-y-2">
                              <div className="flex justify-between items-start">
                                <h3 className="font-semibold text-sm flex items-center">
                                  {product.name}
                                  <Star className="ml-1 h-3 w-3 text-yellow-500 fill-current" />
                                </h3>
                                {product.preparation_time > 0 && (
                                  <Badge variant="outline" className="text-xs">
                                    <Clock className="mr-1 h-3 w-3" />
                                    {product.preparation_time}min
                                  </Badge>
                                )}
                              </div>
                              <p className="text-xs text-muted-foreground">{product.description}</p>
                              <p className="text-xs text-muted-foreground">{product.category}</p>
                              <div className="flex justify-between items-center">
                                <span className="text-lg font-bold">${product.price.toFixed(2)}</span>
                                <Badge variant="outline">
                                  {Math.floor(product.price * product.points_per_dollar)} pts
                                </Badge>
                              </div>
                              <div className="flex justify-between items-center">
                                <Badge variant={product.stock_quantity > 10 ? "default" : "destructive"}>
                                  Stock: {product.stock_quantity}
                                </Badge>
                                <Button
                                  onClick={() => addToCart(product)}
                                  className="w-full"
                                  size="sm"
                                  disabled={product.stock_quantity <= 0}
                                >
                                  <Plus className="mr-2 h-4 w-4" />
                                  Agregar
                                </Button>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>

          {/* Panel de Carrito y Pago */}
          <div className="space-y-4">
            {/* Búsqueda de Miembro */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <QrCode className="mr-2 h-5 w-5" />
                  Miembro VIP
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex space-x-2">
                  <Input
                    placeholder="Código de miembro"
                    value={memberCode}
                    onChange={(e) => setMemberCode(e.target.value)}
                    onKeyPress={(e) => e.key === "Enter" && searchMember()}
                  />
                  <Button onClick={searchMember} disabled={loading}>
                    {loading ? "..." : "Buscar"}
                  </Button>
                </div>
                {member && (
                  <Alert>
                    <AlertDescription>
                      <strong>{member.full_name}</strong>
                      <br />
                      Puntos disponibles: {member.loyalty_points}
                    </AlertDescription>
                  </Alert>
                )}
              </CardContent>
            </Card>

            {/* Carrito */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span className="flex items-center">
                    <ShoppingCart className="mr-2 h-5 w-5" />
                    Carrito ({cart.length})
                  </span>
                  {cart.length > 0 && (
                    <Button variant="ghost" size="sm" onClick={clearCart}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent>
                {cart.length === 0 ? (
                  <p className="text-center text-muted-foreground py-4">Carrito vacío</p>
                ) : (
                  <div className="space-y-3">
                    {cart.map((item) => (
                      <div key={item.id} className="flex items-center justify-between">
                        <div className="flex-1">
                          <p className="font-medium text-sm">{item.name}</p>
                          <p className="text-xs text-muted-foreground">${item.price.toFixed(2)} c/u</p>
                          {item.preparation_time > 0 && (
                            <p className="text-xs text-muted-foreground flex items-center">
                              <Clock className="mr-1 h-3 w-3" />
                              {item.preparation_time * item.quantity}min total
                            </p>
                          )}
                        </div>
                        <div className="flex items-center space-x-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => updateQuantity(item.id, item.quantity - 1)}
                          >
                            <Minus className="h-3 w-3" />
                          </Button>
                          <span className="w-8 text-center">{item.quantity}</span>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => updateQuantity(item.id, item.quantity + 1)}
                          >
                            <Plus className="h-3 w-3" />
                          </Button>
                        </div>
                        <div className="text-right ml-2">
                          <p className="font-semibold">${item.subtotal.toFixed(2)}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Resumen y Pago */}
            {cart.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Calculator className="mr-2 h-5 w-5" />
                    Resumen
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>Subtotal:</span>
                      <span>${calculateTotal().toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-sm text-muted-foreground">
                      <span>Puntos a ganar:</span>
                      <span>{calculateLoyaltyPoints()} pts</span>
                    </div>
                    {getTotalPreparationTime() > 0 && (
                      <div className="flex justify-between text-sm text-muted-foreground">
                        <span>Tiempo de preparación:</span>
                        <span>{getTotalPreparationTime()} min</span>
                      </div>
                    )}
                    <div className="border-t pt-2">
                      <div className="flex justify-between font-bold text-lg">
                        <span>Total:</span>
                        <span>${calculateTotal().toFixed(2)}</span>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <Label>Método de Pago</Label>
                    <div className="grid grid-cols-3 gap-2">
                      <Button
                        variant={paymentMethod === "card" ? "default" : "outline"}
                        size="sm"
                        onClick={() => setPaymentMethod("card")}
                      >
                        {getPaymentIcon("card")}
                        Tarjeta
                      </Button>
                      <Button
                        variant={paymentMethod === "cash" ? "default" : "outline"}
                        size="sm"
                        onClick={() => setPaymentMethod("cash")}
                      >
                        {getPaymentIcon("cash")}
                        Efectivo
                      </Button>
                      <Button
                        variant={paymentMethod === "digital" ? "default" : "outline"}
                        size="sm"
                        onClick={() => setPaymentMethod("digital")}
                      >
                        {getPaymentIcon("digital")}
                        Digital
                      </Button>
                    </div>
                  </div>

                  <Button onClick={processPayment} disabled={processing} className="w-full" size="lg">
                    {processing ? (
                      "Procesando..."
                    ) : (
                      <>
                        <Receipt className="mr-2 h-4 w-4" />
                        Procesar Pago
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </AuthGuard>
  )
}
