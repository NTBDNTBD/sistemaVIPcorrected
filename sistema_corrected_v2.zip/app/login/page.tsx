import { createClient, isSupabaseConfigured } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import LoginForm from "@/components/login-form"

export default async function LoginPage() {
  if (!isSupabaseConfigured) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-blue-600 to-purple-600">
        <div className="text-center text-white space-y-4">
          <h1 className="text-3xl font-bold">La EX's Bar VIP</h1>
          <p className="text-xl">Sistema de Gestión Completo</p>
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 max-w-md">
            <h2 className="text-lg font-semibold mb-4">Modo Demo Activo</h2>
            <p className="text-sm mb-4">Credenciales de prueba:</p>
            <div className="space-y-2 text-sm">
              <div className="bg-white/20 rounded p-2">
                <strong>Manager:</strong> manager@barvip.com / manager123
              </div>
              <div className="bg-white/20 rounded p-2">
                <strong>Admin:</strong> admin@barvip.com / demo123
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }

  // Check if user is already logged in
  const supabase = createClient()
  const {
    data: { session },
  } = await supabase.auth.getSession()

  // If user is logged in, redirect to dashboard
  if (session) {
    redirect("/dashboard")
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-blue-600 to-purple-600 px-4 py-12 sm:px-6 lg:px-8">
      <LoginForm />
    </div>
  )
}
