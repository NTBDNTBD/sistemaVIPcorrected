"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { supabase, isDemo } from "@/lib/supabase/client"
import { AuthGuard } from "@/components/auth-guard"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Gift, Percent, Star, Plus, Edit } from "lucide-react"

interface Reward {
  id: string
  name: string
  description: string
  points_required: number
  reward_type: string
  reward_value: number
  is_active: boolean
}

const demoRewards = [
  {
    id: "reward-1",
    name: "Descuento 10%",
    description: "Descuento del 10% en tu próxima compra",
    points_required: 50,
    reward_type: "discount",
    reward_value: 10.0,
    is_active: true,
  },
  {
    id: "reward-2",
    name: "Cocktail Gratis",
    description: "Cocktail signature gratuito",
    points_required: 100,
    reward_type: "free_item",
    reward_value: 80.0,
    is_active: true,
  },
  {
    id: "reward-3",
    name: "Acceso Área VIP+",
    description: "Acceso al área más exclusiva por una noche",
    points_required: 200,
    reward_type: "special_access",
    reward_value: 0.0,
    is_active: true,
  },
]

export default function RewardsPage() {
  const [rewards, setRewards] = useState<Reward[]>([])
  const [loading, setLoading] = useState(true)
  const [showAddDialog, setShowAddDialog] = useState(false)
  const [showEditDialog, setShowEditDialog] = useState(false)
  const [selectedReward, setSelectedReward] = useState<Reward | null>(null)
  const [newReward, setNewReward] = useState({
    name: "",
    description: "",
    points_required: 0,
    reward_type: "discount",
    reward_value: 0,
    is_active: true,
  })

  const loadRewards = async () => {
    console.log("🔄 Loading rewards...")
    try {
      if (isDemo()) {
        console.log("📱 Demo mode - loading local rewards")
        setRewards(demoRewards)
        setLoading(false)
        return
      }

      console.log("🚀 Supabase mode - fetching rewards from database")
      const { data, error } = await supabase.from("rewards").select("*").eq("is_active", true)

      if (error) {
        console.error("❌ Supabase fetch error:", error)
        throw error
      }
      console.log("✅ Rewards loaded from Supabase:", data)
      setRewards(data || [])
    } catch (error) {
      console.error("❌ Error loading rewards, falling back to demo:", error)
      setRewards(demoRewards)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadRewards()
  }, [])

  const getRewardIcon = (type: string) => {
    switch (type) {
      case "discount":
        return <Percent className="h-4 w-4" />
      case "free_item":
        return <Gift className="h-4 w-4" />
      case "special_access":
        return <Star className="h-4 w-4" />
      default:
        return <Gift className="h-4 w-4" />
    }
  }

  const getRewardTypeLabel = (type: string) => {
    switch (type) {
      case "discount":
        return "Descuento"
      case "free_item":
        return "Producto Gratis"
      case "special_access":
        return "Acceso Especial"
      default:
        return type
    }
  }

  const handleAddReward = async (e: React.FormEvent) => {
    e.preventDefault()
    
    console.log("🎯 Form submitted! Current reward data:", newReward)
    console.log("🔍 Is demo mode?", isDemo())

    // Validate required fields
    if (!newReward.name.trim()) {
      alert("Por favor ingresa el nombre del premio")
      return
    }
    if (!newReward.description.trim()) {
      alert("Por favor ingresa la descripción del premio")
      return
    }
    if (newReward.points_required <= 0) {
      alert("Los puntos requeridos deben ser mayor a 0")
      return
    }

    const rewardData = {
      id: `reward-${Date.now()}`,
      ...newReward,
    }

    console.log("📝 Final reward data to insert:", rewardData)

    if (isDemo()) {
      console.log("✅ Demo mode - adding reward locally")
      setRewards((prev) => [rewardData, ...prev])
      console.log("✅ Reward added to local state")
      alert("✅ Premio agregado exitosamente (Modo Demo)")
    } else {
      try {
        console.log("🚀 Supabase mode - inserting reward:", rewardData)
        const { data, error } = await supabase.from("rewards").insert([rewardData]).select()
        if (error) {
          console.error("❌ Supabase error:", error)
          alert(`Error de base de datos: ${error.message}`)
          return
        }
        console.log("✅ Reward added successfully to Supabase:", data)
        alert("✅ Premio agregado exitosamente")
        await loadRewards()
      } catch (error) {
        console.error("❌ Unexpected error:", error)
        alert(`Error inesperado: ${error.message || 'Error desconocido'}`)
        return
      }
    }

    // Reset form and close dialog
    console.log("🧹 Resetting form and closing dialog")
    setNewReward({
      name: "",
      description: "",
      points_required: 0,
      reward_type: "discount",
      reward_value: 0,
      is_active: true,
    })
    setShowAddDialog(false)
    console.log("✅ Form reset complete")
  }

  const handleEditReward = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!selectedReward) return

    console.log("✏️ Editing reward:", selectedReward.id, newReward)

    if (isDemo()) {
      console.log("✅ Demo mode - updating reward locally")
      setRewards((prev) =>
        prev.map((reward) => (reward.id === selectedReward.id ? { ...reward, ...newReward } : reward)),
      )
      alert("✅ Premio actualizado exitosamente (Modo Demo)")
    } else {
      try {
        console.log("🚀 Supabase mode - updating reward")
        const { error } = await supabase.from("rewards").update(newReward).eq("id", selectedReward.id)
        if (error) {
          console.error("❌ Supabase update error:", error)
          alert(`Error al actualizar: ${error.message}`)
          return
        }
        console.log("✅ Reward updated successfully")
        alert("✅ Premio actualizado exitosamente")
        loadRewards()
      } catch (error) {
        console.error("❌ Error updating reward:", error)
        alert(`Error inesperado: ${error.message || 'Error desconocido'}`)
        return
      }
    }

    setShowEditDialog(false)
    setSelectedReward(null)
  }

  const openEditDialog = (reward: Reward) => {
    console.log("📝 Opening edit dialog for reward:", reward.id)
    setSelectedReward(reward)
    setNewReward({
      name: reward.name,
      description: reward.description,
      points_required: reward.points_required,
      reward_type: reward.reward_type,
      reward_value: reward.reward_value,
      is_active: reward.is_active,
    })
    setShowEditDialog(true)
  }

  if (loading) {
    return (
      <AuthGuard requiredPermissions={["manage_products"]}>
        <div className="flex items-center justify-center min-h-screen">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </div>
      </AuthGuard>
    )
  }

  return (
    <AuthGuard requiredPermissions={["manage_products"]}>
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Programa de Premios</h1>
            <p className="text-muted-foreground">
              Gestiona los premios y recompensas del programa de lealtad
              {isDemo() && <span className="ml-2 text-orange-500">(Modo Demo)</span>}
            </p>
          </div>
          <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Agregar Premio
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Agregar Nuevo Premio</DialogTitle>
                <DialogDescription>Crea un nuevo premio para el programa de lealtad</DialogDescription>
              </DialogHeader>
              <form onSubmit={(e) => {
                console.log("🎯 Form onSubmit triggered")
                handleAddReward(e)
              }}>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="name">Nombre del Premio</Label>
                    <Input
                      id="name"
                      value={newReward.name}
                      onChange={(e) => setNewReward((prev) => ({ ...prev, name: e.target.value }))}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="description">Descripción</Label>
                    <Input
                      id="description"
                      value={newReward.description}
                      onChange={(e) => setNewReward((prev) => ({ ...prev, description: e.target.value }))}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="points_required">Puntos Requeridos</Label>
                    <Input
                      id="points_required"
                      type="number"
                      value={newReward.points_required}
                      onChange={(e) =>
                        setNewReward((prev) => ({ ...prev, points_required: Number.parseInt(e.target.value) || 0 }))
                      }
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="reward_type">Tipo de Premio</Label>
                    <Select
                      value={newReward.reward_type}
                      onValueChange={(value) => setNewReward((prev) => ({ ...prev, reward_type: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="discount">Descuento</SelectItem>
                        <SelectItem value="free_item">Producto Gratis</SelectItem>
                        <SelectItem value="special_access">Acceso Especial</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="reward_value">Valor del Premio</Label>
                    <Input
                      id="reward_value"
                      type="number"
                      step="0.01"
                      value={newReward.reward_value}
                      onChange={(e) =>
                        setNewReward((prev) => ({ ...prev, reward_value: Number.parseFloat(e.target.value) || 0 }))
                      }
                    />
                  </div>
                </div>
                <DialogFooter className="mt-6">
                  <Button type="button" variant="outline" onClick={() => setShowAddDialog(false)}>
                    Cancelar
                  </Button>
                  <Button 
                    type="button"
                    variant="secondary"
                    onClick={() => {
                      console.log("🧪 Test button clicked")
                      alert("✅ Test: Función funciona correctamente")
                    }}
                  >
                    Test
                  </Button>
                  <Button type="submit">Crear Premio</Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Premios Disponibles</CardTitle>
            <CardDescription>Recompensas que los miembros pueden canjear con sus puntos</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Premio</TableHead>
                  <TableHead>Descripción</TableHead>
                  <TableHead>Tipo</TableHead>
                  <TableHead>Puntos Requeridos</TableHead>
                  <TableHead>Valor</TableHead>
                  <TableHead>Estado</TableHead>
                  <TableHead>Acciones</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rewards.map((reward) => (
                  <TableRow key={reward.id}>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        {getRewardIcon(reward.reward_type)}
                        <span className="font-medium">{reward.name}</span>
                      </div>
                    </TableCell>
                    <TableCell>{reward.description}</TableCell>
                    <TableCell>
                      <Badge variant="outline">{getRewardTypeLabel(reward.reward_type)}</Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-1">
                        <Gift className="h-4 w-4 text-muted-foreground" />
                        <span>{reward.points_required} pts</span>
                      </div>
                    </TableCell>
                    <TableCell>{reward.reward_value > 0 ? `$${reward.reward_value.toFixed(2)}` : "N/A"}</TableCell>
                    <TableCell>
                      <Badge variant={reward.is_active ? "default" : "secondary"}>
                        {reward.is_active ? "Activo" : "Inactivo"}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Button variant="outline" size="sm" onClick={() => openEditDialog(reward)}>
                        <Edit className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Editar Premio</DialogTitle>
              <DialogDescription>Modifica los detalles del premio</DialogDescription>
            </DialogHeader>
            <form onSubmit={handleEditReward}>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="edit_name">Nombre del Premio</Label>
                  <Input
                    id="edit_name"
                    value={newReward.name}
                    onChange={(e) => setNewReward((prev) => ({ ...prev, name: e.target.value }))}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="edit_description">Descripción</Label>
                  <Input
                    id="edit_description"
                    value={newReward.description}
                    onChange={(e) => setNewReward((prev) => ({ ...prev, description: e.target.value }))}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="edit_points_required">Puntos Requeridos</Label>
                  <Input
                    id="edit_points_required"
                    type="number"
                    value={newReward.points_required}
                    onChange={(e) =>
                      setNewReward((prev) => ({ ...prev, points_required: Number.parseInt(e.target.value) || 0 }))
                    }
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="edit_reward_type">Tipo de Premio</Label>
                  <Select
                    value={newReward.reward_type}
                    onValueChange={(value) => setNewReward((prev) => ({ ...prev, reward_type: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="discount">Descuento</SelectItem>
                      <SelectItem value="free_item">Producto Gratis</SelectItem>
                      <SelectItem value="special_access">Acceso Especial</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="edit_reward_value">Valor del Premio</Label>
                  <Input
                    id="edit_reward_value"
                    type="number"
                    step="0.01"
                    value={newReward.reward_value}
                    onChange={(e) =>
                      setNewReward((prev) => ({ ...prev, reward_value: Number.parseFloat(e.target.value) || 0 }))
                    }
                  />
                </div>
              </div>
              <DialogFooter className="mt-6">
                <Button type="button" variant="outline" onClick={() => setShowEditDialog(false)}>
                  Cancelar
                </Button>
                <Button type="submit">Guardar Cambios</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>
    </AuthGuard>
  )
}