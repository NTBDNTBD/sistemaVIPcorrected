import { createClient } from "@/lib/supabase/server"

export default async function TestAuthPage() {
  const supabase = createClient()

  // Test database connection
  let dbTest = null
  let authTest = null

  try {
    // Test if we can query the database
    const { data: tables, error: dbError } = await supabase.from("system_users").select("*").limit(1)

    dbTest = { success: !dbError, error: dbError?.message, data: tables }
  } catch (error) {
    dbTest = { success: false, error: error.message }
  }

  try {
    // Test authentication
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()
    authTest = { success: !authError, user: user?.email, error: authError?.message }
  } catch (error) {
    authTest = { success: false, error: error.message }
  }

  return (
    <div className="p-8 max-w-2xl mx-auto">
      <h1 className="text-2xl font-bold mb-6">Sistema de Pruebas - VIP Bar Management</h1>

      <div className="space-y-6">
        <div className="border rounded-lg p-4">
          <h2 className="text-lg font-semibold mb-2">Conexión a Base de Datos</h2>
          <div className={`p-2 rounded ${dbTest?.success ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}`}>
            {dbTest?.success ? "✅ Conectado correctamente" : `❌ Error: ${dbTest?.error}`}
          </div>
          {dbTest?.data && (
            <pre className="mt-2 text-xs bg-gray-100 p-2 rounded overflow-auto">
              {JSON.stringify(dbTest.data, null, 2)}
            </pre>
          )}
        </div>

        <div className="border rounded-lg p-4">
          <h2 className="text-lg font-semibold mb-2">Sistema de Autenticación</h2>
          <div
            className={`p-2 rounded ${authTest?.success ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}`}
          >
            {authTest?.success
              ? `✅ Sistema funcionando${authTest.user ? ` - Usuario: ${authTest.user}` : " - Sin usuario logueado"}`
              : `❌ Error: ${authTest?.error}`}
          </div>
        </div>

        <div className="border rounded-lg p-4">
          <h2 className="text-lg font-semibold mb-2">Acciones de Prueba</h2>
          <div className="space-y-2">
            <a href="/login" className="block bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">
              Ir a Login
            </a>
            <a href="/dashboard" className="block bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600">
              Ir a Dashboard
            </a>
            <a href="/pos" className="block bg-purple-500 text-white px-4 py-2 rounded hover:bg-purple-600">
              Ir a POS
            </a>
          </div>
        </div>
      </div>
    </div>
  )
}
