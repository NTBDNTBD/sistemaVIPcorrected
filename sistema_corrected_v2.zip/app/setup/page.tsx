"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  CheckCircle,
  XCircle,
  AlertTriangle,
  Database,
  MessageSquare,
  Mail,
  Shield,
  Copy,
  ExternalLink,
  Rocket,
  Settings,
} from "lucide-react"
import { checkConfiguration, getConfigurationSteps, type ConfigStatus } from "@/lib/config-checker"
import { useToast } from "@/hooks/use-toast"

export default function SetupPage() {
  const [config, setConfig] = useState<ConfigStatus | null>(null)
  const [steps, setSteps] = useState<string[]>([])
  const { toast } = useToast()

  useEffect(() => {
    const configuration = checkConfiguration()
    setConfig(configuration)
    setSteps(getConfigurationSteps(configuration))
  }, [])

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    toast({
      title: "Copiado",
      description: "Texto copiado al portapapeles",
    })
  }

  const envTemplate = `# Supabase Configuration
NEXT_PUBLIC_SUPABASE_URL=https://tu-proyecto.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...

# Twilio Configuration (Opcional)
TWILIO_ACCOUNT_SID=ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
TWILIO_AUTH_TOKEN=tu_auth_token_aqui
TWILIO_PHONE_NUMBER=+1234567890
TWILIO_WHATSAPP_NUMBER=+14155238886

# SendGrid Configuration (Opcional)
SENDGRID_API_KEY=SG.xxxxxxxxxxxxxxxxxxxxxxxx
FROM_EMAIL=noreply@tudominio.com

# Security
NOTIFICATION_CRON_TOKEN=tu_token_secreto_aqui`

  if (!config) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Configuración de Producción</h1>
          <p className="text-muted-foreground">Configura el sistema para usar en producción con base de datos real</p>
        </div>
        <Badge variant={config.mode === "production" ? "default" : "secondary"} className="text-lg px-4 py-2">
          {config.mode === "production" ? (
            <>
              <Rocket className="mr-2 h-4 w-4" />
              Modo Producción
            </>
          ) : (
            <>
              <Settings className="mr-2 h-4 w-4" />
              Modo Demo
            </>
          )}
        </Badge>
      </div>

      {config.mode === "demo" && (
        <Alert>
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            <strong>Sistema en Modo Demo:</strong> Los datos se guardan localmente. Para usar en producción, configura
            Supabase siguiendo los pasos a continuación.
          </AlertDescription>
        </Alert>
      )}

      <Tabs defaultValue="status" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="status">Estado Actual</TabsTrigger>
          <TabsTrigger value="supabase">Supabase</TabsTrigger>
          <TabsTrigger value="notifications">Notificaciones</TabsTrigger>
          <TabsTrigger value="deployment">Despliegue</TabsTrigger>
        </TabsList>

        <TabsContent value="status">
          <div className="grid gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Database className="mr-2 h-5 w-5" />
                  Estado de Configuración
                </CardTitle>
                <CardDescription>Resumen del estado actual de todas las integraciones</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Base de Datos (Supabase)</span>
                      {config.supabase.configured ? (
                        <CheckCircle className="h-5 w-5 text-green-500" />
                      ) : (
                        <XCircle className="h-5 w-5 text-red-500" />
                      )}
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">SMS/WhatsApp (Twilio)</span>
                      {config.notifications.twilio.configured ? (
                        <CheckCircle className="h-5 w-5 text-green-500" />
                      ) : (
                        <AlertTriangle className="h-5 w-5 text-yellow-500" />
                      )}
                    </div>
                  </div>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Email (SendGrid)</span>
                      {config.notifications.sendgrid.configured ? (
                        <CheckCircle className="h-5 w-5 text-green-500" />
                      ) : (
                        <AlertTriangle className="h-5 w-5 text-yellow-500" />
                      )}
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Token de Seguridad</span>
                      {config.security.hasCronToken ? (
                        <CheckCircle className="h-5 w-5 text-green-500" />
                      ) : (
                        <AlertTriangle className="h-5 w-5 text-yellow-500" />
                      )}
                    </div>
                  </div>
                </div>

                <div className="border-t pt-4">
                  <h4 className="font-medium mb-2">Pasos Pendientes:</h4>
                  <ul className="space-y-1">
                    {steps.map((step, index) => (
                      <li key={index} className="text-sm text-muted-foreground flex items-start">
                        <span className="mr-2">•</span>
                        {step}
                      </li>
                    ))}
                  </ul>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="supabase">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Database className="mr-2 h-5 w-5" />
                Configuración de Supabase
              </CardTitle>
              <CardDescription>Base de datos principal del sistema - REQUERIDO para modo producción</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <h4 className="font-medium">Estado Actual</h4>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">URL Configurada</span>
                      <Badge variant={config.supabase.url ? "default" : "secondary"}>
                        {config.supabase.url ? "Sí" : "No"}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">API Key Configurada</span>
                      <Badge variant={config.supabase.hasAnonKey ? "default" : "secondary"}>
                        {config.supabase.hasAnonKey ? "Sí" : "No"}
                      </Badge>
                    </div>
                  </div>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium">Enlaces Útiles</h4>
                  <div className="space-y-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full justify-start bg-transparent"
                      onClick={() => window.open("https://supabase.com", "_blank")}
                    >
                      <ExternalLink className="mr-2 h-4 w-4" />
                      Crear Proyecto Supabase
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full justify-start bg-transparent"
                      onClick={() => window.open("https://supabase.com/docs/guides/getting-started", "_blank")}
                    >
                      <ExternalLink className="mr-2 h-4 w-4" />
                      Documentación
                    </Button>
                  </div>
                </div>
              </div>

              <Alert>
                <Database className="h-4 w-4" />
                <AlertDescription>
                  <strong>Pasos para configurar Supabase:</strong>
                  <ol className="list-decimal list-inside mt-2 space-y-1">
                    <li>Crea una cuenta en supabase.com</li>
                    <li>Crea un nuevo proyecto</li>
                    <li>Ve a Settings → API</li>
                    <li>Copia la URL y la anon key</li>
                    <li>Agrégalas al archivo .env.local</li>
                    <li>Ejecuta los scripts SQL en el SQL Editor</li>
                  </ol>
                </AlertDescription>
              </Alert>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <h4 className="font-medium">Plantilla .env.local</h4>
                  <Button variant="outline" size="sm" onClick={() => copyToClipboard(envTemplate)}>
                    <Copy className="mr-2 h-4 w-4" />
                    Copiar
                  </Button>
                </div>
                <pre className="bg-muted p-3 rounded-md text-sm overflow-x-auto">{envTemplate}</pre>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="notifications">
          <div className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <MessageSquare className="mr-2 h-5 w-5" />
                  Twilio (SMS/WhatsApp)
                </CardTitle>
                <CardDescription>Opcional - Para enviar notificaciones por SMS y WhatsApp</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <h4 className="font-medium">Estado</h4>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Account SID</span>
                        <Badge variant={config.notifications.twilio.hasSid ? "default" : "secondary"}>
                          {config.notifications.twilio.hasSid ? "Configurado" : "Pendiente"}
                        </Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Auth Token</span>
                        <Badge variant={config.notifications.twilio.hasToken ? "default" : "secondary"}>
                          {config.notifications.twilio.hasToken ? "Configurado" : "Pendiente"}
                        </Badge>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <h4 className="font-medium">Enlaces</h4>
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full justify-start bg-transparent"
                      onClick={() => window.open("https://www.twilio.com", "_blank")}
                    >
                      <ExternalLink className="mr-2 h-4 w-4" />
                      Crear Cuenta Twilio
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Mail className="mr-2 h-5 w-5" />
                  SendGrid (Email)
                </CardTitle>
                <CardDescription>Opcional - Para enviar notificaciones por email</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <h4 className="font-medium">Estado</h4>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm">API Key</span>
                        <Badge variant={config.notifications.sendgrid.hasApiKey ? "default" : "secondary"}>
                          {config.notifications.sendgrid.hasApiKey ? "Configurado" : "Pendiente"}
                        </Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Email Remitente</span>
                        <Badge variant={config.notifications.sendgrid.hasFromEmail ? "default" : "secondary"}>
                          {config.notifications.sendgrid.hasFromEmail ? "Configurado" : "Pendiente"}
                        </Badge>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <h4 className="font-medium">Enlaces</h4>
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full justify-start bg-transparent"
                      onClick={() => window.open("https://sendgrid.com", "_blank")}
                    >
                      <ExternalLink className="mr-2 h-4 w-4" />
                      Crear Cuenta SendGrid
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="deployment">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Rocket className="mr-2 h-5 w-5" />
                Despliegue en Producción
              </CardTitle>
              <CardDescription>Opciones para desplegar el sistema en producción</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Vercel (Recomendado)</CardTitle>
                    <CardDescription>Despliegue automático y escalable</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <ul className="text-sm space-y-1">
                      <li>• Despliegue automático desde Git</li>
                      <li>• SSL automático</li>
                      <li>• CDN global</li>
                      <li>• Variables de entorno seguras</li>
                    </ul>
                    <Button className="w-full" onClick={() => window.open("https://vercel.com", "_blank")}>
                      <ExternalLink className="mr-2 h-4 w-4" />
                      Desplegar en Vercel
                    </Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Servidor Propio</CardTitle>
                    <CardDescription>Control total del hosting</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <ul className="text-sm space-y-1">
                      <li>• npm run build</li>
                      <li>• npm start</li>
                      <li>• Configurar nginx/apache</li>
                      <li>• SSL con Let's Encrypt</li>
                    </ul>
                    <Button
                      variant="outline"
                      className="w-full bg-transparent"
                      onClick={() => window.open("https://nextjs.org/docs/deployment", "_blank")}
                    >
                      <ExternalLink className="mr-2 h-4 w-4" />
                      Guía de Despliegue
                    </Button>
                  </CardContent>
                </Card>
              </div>

              <Alert>
                <Shield className="h-4 w-4" />
                <AlertDescription>
                  <strong>Checklist de Seguridad para Producción:</strong>
                  <ul className="list-disc list-inside mt-2 space-y-1">
                    <li>Cambiar todas las contraseñas por defecto</li>
                    <li>Configurar variables de entorno seguras</li>
                    <li>Habilitar SSL/HTTPS</li>
                    <li>Configurar backups automáticos</li>
                    <li>Monitorear logs de acceso</li>
                  </ul>
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
