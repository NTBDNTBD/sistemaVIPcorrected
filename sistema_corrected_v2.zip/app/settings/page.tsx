"use client"

import { useEffect, useState } from "react"
import { getSupabaseClient, isDemo } from "@/lib/supabase"
import { AuthGuard } from "@/components/auth-guard"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/hooks/use-toast"
import {
  Settings,
  MessageSquare,
  Mail,
  Smartphone,
  Shield,
  Building,
  Clock,
  Eye,
  EyeOff,
  Save,
  TestTube,
} from "lucide-react"

interface SystemSettings {
  // Configuración del Bar
  barName: string
  contactPhone: string
  contactEmail: string
  address: string
  renewalLink: string

  // Configuración de Twilio
  twilioAccountSid: string
  twilioAuthToken: string
  twilioPhoneNumber: string
  twilioWhatsAppNumber: string

  // Configuración de SendGrid
  sendgridApiKey: string
  fromEmail: string

  // Configuración de Notificaciones
  notificationsEnabled: boolean
  smsEnabled: boolean
  whatsappEnabled: boolean
  emailEnabled: boolean

  // Tiempos de Notificación
  expiringDaysBefore: number
  expiredDaysAfter: number
  welcomeDelayMinutes: number

  // Configuración de Seguridad
  notificationCronToken: string
  encryptSensitiveData: boolean
}

const defaultSettings: SystemSettings = {
  barName: "Bar VIP",
  contactPhone: "+1234567890",
  contactEmail: "info@barvip.com",
  address: "123 VIP Street, City",
  renewalLink: "https://barvip.com/renovar",

  twilioAccountSid: "",
  twilioAuthToken: "",
  twilioPhoneNumber: "",
  twilioWhatsAppNumber: "+14155238886",

  sendgridApiKey: "",
  fromEmail: "noreply@barvip.com",

  notificationsEnabled: true,
  smsEnabled: true,
  whatsappEnabled: true,
  emailEnabled: true,

  expiringDaysBefore: 7,
  expiredDaysAfter: 7,
  welcomeDelayMinutes: 5,

  notificationCronToken: "",
  encryptSensitiveData: true,
}

export default function SettingsPage() {
  const [settings, setSettings] = useState<SystemSettings>(defaultSettings)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [testing, setTesting] = useState(false)
  const [showSensitive, setShowSensitive] = useState({
    twilioToken: false,
    sendgridKey: false,
    cronToken: false,
  })
  const { toast } = useToast()

  useEffect(() => {
    loadSettings()
  }, [])

  const loadSettings = async () => {
    try {
      if (isDemo()) {
        // En modo demo, cargar desde localStorage
        const savedSettings = localStorage.getItem("vip_bar_settings")
        if (savedSettings) {
          setSettings({ ...defaultSettings, ...JSON.parse(savedSettings) })
        }
        setLoading(false)
        return
      }

      const supabase = getSupabaseClient()
      const { data, error } = await supabase.from("notification_settings").select("setting_key, setting_value")

      if (error) {
        console.error("Error loading settings:", error)
        if (error.message.includes("does not exist")) {
          console.log("notification_settings table not found, using default settings")
          setSettings(defaultSettings)
        } else {
          throw error
        }
        setLoading(false)
        return
      }

      const settingsMap =
        data?.reduce(
          (acc, item) => {
            acc[item.setting_key] = item.setting_value
            return acc
          },
          {} as Record<string, string>,
        ) || {}

      setSettings({
        barName: settingsMap.bar_name || defaultSettings.barName,
        contactPhone: settingsMap.contact_phone || defaultSettings.contactPhone,
        contactEmail: settingsMap.contact_email || defaultSettings.contactEmail,
        address: settingsMap.address || defaultSettings.address,
        renewalLink: settingsMap.renewal_link || defaultSettings.renewalLink,

        twilioAccountSid: settingsMap.twilio_account_sid || "",
        twilioAuthToken: settingsMap.twilio_auth_token || "",
        twilioPhoneNumber: settingsMap.twilio_phone_number || "",
        twilioWhatsAppNumber: settingsMap.twilio_whatsapp_number || defaultSettings.twilioWhatsAppNumber,

        sendgridApiKey: settingsMap.sendgrid_api_key || "",
        fromEmail: settingsMap.from_email || defaultSettings.fromEmail,

        notificationsEnabled: settingsMap.notifications_enabled === "true",
        smsEnabled: settingsMap.sms_enabled !== "false",
        whatsappEnabled: settingsMap.whatsapp_enabled !== "false",
        emailEnabled: settingsMap.email_enabled !== "false",

        expiringDaysBefore: Number.parseInt(settingsMap.expiring_days_before || "7"),
        expiredDaysAfter: Number.parseInt(settingsMap.expired_days_after || "7"),
        welcomeDelayMinutes: Number.parseInt(settingsMap.welcome_delay_minutes || "5"),

        notificationCronToken: settingsMap.notification_cron_token || "",
        encryptSensitiveData: settingsMap.encrypt_sensitive_data !== "false",
      })
    } catch (error) {
      console.error("Error loading settings:", error)
      toast({
        title: "Error",
        description: "No se pudieron cargar las configuraciones",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const saveSettings = async () => {
    setSaving(true)
    try {
      if (isDemo()) {
        // En modo demo, guardar en localStorage
        localStorage.setItem("vip_bar_settings", JSON.stringify(settings))
        toast({
          title: "Configuración Guardada",
          description: "Las configuraciones se han guardado en modo demo",
        })
        setSaving(false)
        return
      }

      const supabase = getSupabaseClient()

      const settingsToSave = [
        { setting_key: "bar_name", setting_value: settings.barName },
        { setting_key: "contact_phone", setting_value: settings.contactPhone },
        { setting_key: "contact_email", setting_value: settings.contactEmail },
        { setting_key: "address", setting_value: settings.address },
        { setting_key: "renewal_link", setting_value: settings.renewalLink },

        { setting_key: "twilio_account_sid", setting_value: settings.twilioAccountSid },
        { setting_key: "twilio_auth_token", setting_value: settings.twilioAuthToken },
        { setting_key: "twilio_phone_number", setting_value: settings.twilioPhoneNumber },
        { setting_key: "twilio_whatsapp_number", setting_value: settings.twilioWhatsAppNumber },

        { setting_key: "sendgrid_api_key", setting_value: settings.sendgridApiKey },
        { setting_key: "from_email", setting_value: settings.fromEmail },

        { setting_key: "notifications_enabled", setting_value: settings.notificationsEnabled.toString() },
        { setting_key: "sms_enabled", setting_value: settings.smsEnabled.toString() },
        { setting_key: "whatsapp_enabled", setting_value: settings.whatsappEnabled.toString() },
        { setting_key: "email_enabled", setting_value: settings.emailEnabled.toString() },

        { setting_key: "expiring_days_before", setting_value: settings.expiringDaysBefore.toString() },
        { setting_key: "expired_days_after", setting_value: settings.expiredDaysAfter.toString() },
        { setting_key: "welcome_delay_minutes", setting_value: settings.welcomeDelayMinutes.toString() },

        { setting_key: "notification_cron_token", setting_value: settings.notificationCronToken },
        { setting_key: "encrypt_sensitive_data", setting_value: settings.encryptSensitiveData.toString() },
      ]

      for (const setting of settingsToSave) {
        await supabase.from("notification_settings").upsert(setting, { onConflict: "setting_key" })
      }

      toast({
        title: "Configuración Guardada",
        description: "Todas las configuraciones se han guardado exitosamente",
      })
    } catch (error) {
      console.error("Error saving settings:", error)
      toast({
        title: "Error",
        description: "No se pudieron guardar las configuraciones",
        variant: "destructive",
      })
    } finally {
      setSaving(false)
    }
  }

  const testNotifications = async () => {
    setTesting(true)
    try {
      const response = await fetch("/api/notifications/test", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          twilioAccountSid: settings.twilioAccountSid,
          twilioAuthToken: settings.twilioAuthToken,
          sendgridApiKey: settings.sendgridApiKey,
        }),
      })

      const result = await response.json()

      if (result.success) {
        toast({
          title: "Prueba Exitosa",
          description: "Las configuraciones de notificación funcionan correctamente",
        })
      } else {
        toast({
          title: "Error en Prueba",
          description: result.error || "Las configuraciones no funcionan correctamente",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "No se pudo realizar la prueba",
        variant: "destructive",
      })
    } finally {
      setTesting(false)
    }
  }

  const generateToken = () => {
    const token = Array.from(crypto.getRandomValues(new Uint8Array(32)))
      .map((b) => b.toString(16).padStart(2, "0"))
      .join("")
    setSettings((prev) => ({ ...prev, notificationCronToken: token }))
  }

  if (loading) {
    return (
      <AuthGuard requiredPermissions={["manage_users"]}>
        <div className="flex items-center justify-center min-h-screen">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </div>
      </AuthGuard>
    )
  }

  return (
    <AuthGuard requiredPermissions={["manage_users"]}>
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Configuración del Sistema</h1>
            <p className="text-muted-foreground">
              Configura las integraciones y ajustes del sistema
              {isDemo() && <span className="ml-2 text-orange-500">(Modo Demo - Datos guardados localmente)</span>}
            </p>
          </div>
          <div className="flex space-x-2">
            <Button onClick={testNotifications} disabled={testing} variant="outline">
              {testing ? <TestTube className="mr-2 h-4 w-4 animate-spin" /> : <TestTube className="mr-2 h-4 w-4" />}
              Probar Conexiones
            </Button>
            <Button onClick={saveSettings} disabled={saving}>
              {saving ? <Save className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
              Guardar Configuración
            </Button>
          </div>
        </div>

        <Tabs defaultValue="bar" className="space-y-4">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="bar">
              <Building className="mr-2 h-4 w-4" />
              Bar
            </TabsTrigger>
            <TabsTrigger value="notifications">
              <MessageSquare className="mr-2 h-4 w-4" />
              Notificaciones
            </TabsTrigger>
            <TabsTrigger value="timing">
              <Clock className="mr-2 h-4 w-4" />
              Tiempos
            </TabsTrigger>
            <TabsTrigger value="security">
              <Shield className="mr-2 h-4 w-4" />
              Seguridad
            </TabsTrigger>
            <TabsTrigger value="system">
              <Settings className="mr-2 h-4 w-4" />
              Sistema
            </TabsTrigger>
          </TabsList>

          <TabsContent value="bar">
            <Card>
              <CardHeader>
                <CardTitle>Información del Bar</CardTitle>
                <CardDescription>Configura la información básica de tu establecimiento</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="barName">Nombre del Bar</Label>
                    <Input
                      id="barName"
                      value={settings.barName}
                      onChange={(e) => setSettings((prev) => ({ ...prev, barName: e.target.value }))}
                      placeholder="Bar VIP Premium"
                    />
                  </div>
                  <div>
                    <Label htmlFor="contactPhone">Teléfono de Contacto</Label>
                    <Input
                      id="contactPhone"
                      value={settings.contactPhone}
                      onChange={(e) => setSettings((prev) => ({ ...prev, contactPhone: e.target.value }))}
                      placeholder="+1234567890"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="contactEmail">Email de Contacto</Label>
                    <Input
                      id="contactEmail"
                      type="email"
                      value={settings.contactEmail}
                      onChange={(e) => setSettings((prev) => ({ ...prev, contactEmail: e.target.value }))}
                      placeholder="info@barvip.com"
                    />
                  </div>
                  <div>
                    <Label htmlFor="renewalLink">Link de Renovación</Label>
                    <Input
                      id="renewalLink"
                      value={settings.renewalLink}
                      onChange={(e) => setSettings((prev) => ({ ...prev, renewalLink: e.target.value }))}
                      placeholder="https://barvip.com/renovar"
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="address">Dirección</Label>
                  <Textarea
                    id="address"
                    value={settings.address}
                    onChange={(e) => setSettings((prev) => ({ ...prev, address: e.target.value }))}
                    placeholder="123 VIP Street, Ciudad, País"
                    rows={2}
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="notifications">
            <div className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <MessageSquare className="mr-2 h-5 w-5" />
                    Configuración de Twilio (SMS y WhatsApp)
                  </CardTitle>
                  <CardDescription>
                    Configura tu cuenta de Twilio para enviar SMS y mensajes de WhatsApp
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Alert>
                    <Shield className="h-4 w-4" />
                    <AlertDescription>
                      Estos datos se almacenan de forma segura y encriptada en la base de datos.
                    </AlertDescription>
                  </Alert>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="twilioSid">Account SID</Label>
                      <Input
                        id="twilioSid"
                        value={settings.twilioAccountSid}
                        onChange={(e) => setSettings((prev) => ({ ...prev, twilioAccountSid: e.target.value }))}
                        placeholder="ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
                      />
                    </div>
                    <div>
                      <Label htmlFor="twilioToken">Auth Token</Label>
                      <div className="relative">
                        <Input
                          id="twilioToken"
                          type={showSensitive.twilioToken ? "text" : "password"}
                          value={settings.twilioAuthToken}
                          onChange={(e) => setSettings((prev) => ({ ...prev, twilioAuthToken: e.target.value }))}
                          placeholder="Tu Auth Token de Twilio"
                        />
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          className="absolute right-0 top-0 h-full px-3"
                          onClick={() => setShowSensitive((prev) => ({ ...prev, twilioToken: !prev.twilioToken }))}
                        >
                          {showSensitive.twilioToken ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                        </Button>
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="twilioPhone">Número de Teléfono</Label>
                      <Input
                        id="twilioPhone"
                        value={settings.twilioPhoneNumber}
                        onChange={(e) => setSettings((prev) => ({ ...prev, twilioPhoneNumber: e.target.value }))}
                        placeholder="+1234567890"
                      />
                    </div>
                    <div>
                      <Label htmlFor="twilioWhatsApp">Número de WhatsApp</Label>
                      <Input
                        id="twilioWhatsApp"
                        value={settings.twilioWhatsAppNumber}
                        onChange={(e) => setSettings((prev) => ({ ...prev, twilioWhatsAppNumber: e.target.value }))}
                        placeholder="+14155238886"
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Mail className="mr-2 h-5 w-5" />
                    Configuración de SendGrid (Email)
                  </CardTitle>
                  <CardDescription>Configura tu cuenta de SendGrid para enviar emails</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="sendgridKey">API Key</Label>
                      <div className="relative">
                        <Input
                          id="sendgridKey"
                          type={showSensitive.sendgridKey ? "text" : "password"}
                          value={settings.sendgridApiKey}
                          onChange={(e) => setSettings((prev) => ({ ...prev, sendgridApiKey: e.target.value }))}
                          placeholder="SG.xxxxxxxxxxxxxxxxxxxxxxxx"
                        />
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          className="absolute right-0 top-0 h-full px-3"
                          onClick={() => setShowSensitive((prev) => ({ ...prev, sendgridKey: !prev.sendgridKey }))}
                        >
                          {showSensitive.sendgridKey ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                        </Button>
                      </div>
                    </div>
                    <div>
                      <Label htmlFor="fromEmail">Email Remitente</Label>
                      <Input
                        id="fromEmail"
                        type="email"
                        value={settings.fromEmail}
                        onChange={(e) => setSettings((prev) => ({ ...prev, fromEmail: e.target.value }))}
                        placeholder="noreply@barvip.com"
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Canales de Notificación</CardTitle>
                  <CardDescription>Habilita o deshabilita los diferentes canales</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <MessageSquare className="h-4 w-4" />
                      <Label htmlFor="smsEnabled">SMS</Label>
                    </div>
                    <Switch
                      id="smsEnabled"
                      checked={settings.smsEnabled}
                      onCheckedChange={(checked) => setSettings((prev) => ({ ...prev, smsEnabled: checked }))}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Smartphone className="h-4 w-4" />
                      <Label htmlFor="whatsappEnabled">WhatsApp</Label>
                    </div>
                    <Switch
                      id="whatsappEnabled"
                      checked={settings.whatsappEnabled}
                      onCheckedChange={(checked) => setSettings((prev) => ({ ...prev, whatsappEnabled: checked }))}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Mail className="h-4 w-4" />
                      <Label htmlFor="emailEnabled">Email</Label>
                    </div>
                    <Switch
                      id="emailEnabled"
                      checked={settings.emailEnabled}
                      onCheckedChange={(checked) => setSettings((prev) => ({ ...prev, emailEnabled: checked }))}
                    />
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="timing">
            <Card>
              <CardHeader>
                <CardTitle>Configuración de Tiempos</CardTitle>
                <CardDescription>Configura cuándo y cómo enviar las notificaciones</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="expiringDays">Días antes de expirar</Label>
                    <Input
                      id="expiringDays"
                      type="number"
                      min="1"
                      max="30"
                      value={settings.expiringDaysBefore}
                      onChange={(e) =>
                        setSettings((prev) => ({ ...prev, expiringDaysBefore: Number.parseInt(e.target.value) || 7 }))
                      }
                    />
                    <p className="text-sm text-muted-foreground mt-1">
                      Notificar X días antes de que expire la membresía
                    </p>
                  </div>
                  <div>
                    <Label htmlFor="expiredDays">Días después de expirar</Label>
                    <Input
                      id="expiredDays"
                      type="number"
                      min="1"
                      max="30"
                      value={settings.expiredDaysAfter}
                      onChange={(e) =>
                        setSettings((prev) => ({ ...prev, expiredDaysAfter: Number.parseInt(e.target.value) || 7 }))
                      }
                    />
                    <p className="text-sm text-muted-foreground mt-1">Seguir notificando X días después de expirar</p>
                  </div>
                  <div>
                    <Label htmlFor="welcomeDelay">Retraso bienvenida (min)</Label>
                    <Input
                      id="welcomeDelay"
                      type="number"
                      min="0"
                      max="60"
                      value={settings.welcomeDelayMinutes}
                      onChange={(e) =>
                        setSettings((prev) => ({ ...prev, welcomeDelayMinutes: Number.parseInt(e.target.value) || 5 }))
                      }
                    />
                    <p className="text-sm text-muted-foreground mt-1">Esperar X minutos antes de enviar bienvenida</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="security">
            <Card>
              <CardHeader>
                <CardTitle>Configuración de Seguridad</CardTitle>
                <CardDescription>Tokens y configuraciones de seguridad</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="cronToken">Token para Cron de Notificaciones</Label>
                  <div className="flex space-x-2">
                    <div className="relative flex-1">
                      <Input
                        id="cronToken"
                        type={showSensitive.cronToken ? "text" : "password"}
                        value={settings.notificationCronToken}
                        onChange={(e) => setSettings((prev) => ({ ...prev, notificationCronToken: e.target.value }))}
                        placeholder="Token secreto para el cron job"
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        className="absolute right-0 top-0 h-full px-3"
                        onClick={() => setShowSensitive((prev) => ({ ...prev, cronToken: !prev.cronToken }))}
                      >
                        {showSensitive.cronToken ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </Button>
                    </div>
                    <Button onClick={generateToken} variant="outline">
                      Generar Token
                    </Button>
                  </div>
                  <p className="text-sm text-muted-foreground mt-1">
                    Token para proteger el endpoint de procesamiento automático de notificaciones
                  </p>
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="encryptData">Encriptar Datos Sensibles</Label>
                    <p className="text-sm text-muted-foreground">Encriptar tokens y claves API en la base de datos</p>
                  </div>
                  <Switch
                    id="encryptData"
                    checked={settings.encryptSensitiveData}
                    onCheckedChange={(checked) => setSettings((prev) => ({ ...prev, encryptSensitiveData: checked }))}
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="system">
            <Card>
              <CardHeader>
                <CardTitle>Estado del Sistema</CardTitle>
                <CardDescription>Información y estado de las integraciones</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <h4 className="font-medium">Integraciones</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Twilio SMS</span>
                        <Badge
                          variant={settings.twilioAccountSid && settings.twilioAuthToken ? "default" : "secondary"}
                        >
                          {settings.twilioAccountSid && settings.twilioAuthToken ? "Configurado" : "Pendiente"}
                        </Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Twilio WhatsApp</span>
                        <Badge variant={settings.twilioWhatsAppNumber ? "default" : "secondary"}>
                          {settings.twilioWhatsAppNumber ? "Configurado" : "Pendiente"}
                        </Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm">SendGrid Email</span>
                        <Badge variant={settings.sendgridApiKey ? "default" : "secondary"}>
                          {settings.sendgridApiKey ? "Configurado" : "Pendiente"}
                        </Badge>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <h4 className="font-medium">Sistema</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Notificaciones</span>
                        <Badge variant={settings.notificationsEnabled ? "default" : "secondary"}>
                          {settings.notificationsEnabled ? "Habilitadas" : "Deshabilitadas"}
                        </Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Modo</span>
                        <Badge variant={isDemo() ? "secondary" : "default"}>{isDemo() ? "Demo" : "Producción"}</Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Seguridad</span>
                        <Badge variant={settings.encryptSensitiveData ? "default" : "secondary"}>
                          {settings.encryptSensitiveData ? "Encriptado" : "Sin Encriptar"}
                        </Badge>
                      </div>
                    </div>
                  </div>
                </div>

                <Alert>
                  <Settings className="h-4 w-4" />
                  <AlertDescription>
                    {isDemo()
                      ? "En modo demo, las configuraciones se guardan localmente. Para usar en producción, configura Supabase."
                      : "Sistema en modo producción. Las configuraciones se guardan en la base de datos de forma segura."}
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </AuthGuard>
  )
}
