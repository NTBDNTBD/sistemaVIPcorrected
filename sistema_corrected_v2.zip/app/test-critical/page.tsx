"use client"

import { AuthGuard } from "@/components/auth-guard"
import CriticalFunctionalityTest from "@/components/critical-functionality-test"

export default function TestCriticalPage() {
  return (
    <AuthGuard allowDemo>
      <div className="container mx-auto py-6">
        <div className="space-y-6">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Pruebas de Funcionalidades Críticas</h1>
            <p className="text-muted-foreground">
              Verificación completa del estado y funcionamiento de todas las funcionalidades críticas del sistema
            </p>
          </div>

          <CriticalFunctionalityTest />
        </div>
      </div>
    </AuthGuard>
  )
}
