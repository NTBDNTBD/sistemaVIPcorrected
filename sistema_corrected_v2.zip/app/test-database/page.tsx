"use client"

import { useState, useEffect } from "react"
import { createClient } from "@/lib/supabase/client"

export default function TestDatabase() {
  const [results, setResults] = useState<any>({})
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function testDatabase() {
      const supabase = createClient()

      try {
        // Test 1: Check categories
        const { data: categories, error: catError } = await supabase.from("product_categories").select("*")

        // Test 2: Check products
        const { data: products, error: prodError } = await supabase.from("products").select("*")

        // Test 3: Check users
        const { data: users, error: userError } = await supabase.from("system_users").select("email, full_name")

        // Test 4: Check roles
        const { data: roles, error: roleError } = await supabase.from("user_roles").select("name, display_name")

        setResults({
          categories: { data: categories, error: catError },
          products: { data: products, error: prodError },
          users: { data: users, error: userError },
          roles: { data: roles, error: roleError },
        })
      } catch (error) {
        console.error("Database test error:", error)
        setResults({ error: error.message })
      } finally {
        setLoading(false)
      }
    }

    testDatabase()
  }, [])

  if (loading) {
    return (
      <div className="p-8">
        <h1 className="text-2xl font-bold mb-4">Probando Base de Datos...</h1>
        <div className="animate-pulse">Conectando...</div>
      </div>
    )
  }

  return (
    <div className="p-8 max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-6">Prueba de Base de Datos</h1>

      <div className="grid gap-6">
        {/* Categories Test */}
        <div className="border rounded-lg p-4">
          <h2 className="text-xl font-semibold mb-2">Categorías de Productos</h2>
          {results.categories?.error ? (
            <div className="text-red-600">Error: {results.categories.error.message}</div>
          ) : (
            <div>
              <div className="text-green-600 mb-2">✅ Conectado exitosamente</div>
              <div className="text-sm">Total: {results.categories?.data?.length || 0} categorías</div>
              <ul className="mt-2 space-y-1">
                {results.categories?.data?.map((cat: any) => (
                  <li key={cat.id} className="text-sm bg-gray-100 p-2 rounded">
                    {cat.name} - {cat.description}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>

        {/* Products Test */}
        <div className="border rounded-lg p-4">
          <h2 className="text-xl font-semibold mb-2">Productos</h2>
          {results.products?.error ? (
            <div className="text-red-600">Error: {results.products.error.message}</div>
          ) : (
            <div>
              <div className="text-green-600 mb-2">✅ Conectado exitosamente</div>
              <div className="text-sm">Total: {results.products?.data?.length || 0} productos</div>
              <ul className="mt-2 space-y-1">
                {results.products?.data?.map((prod: any) => (
                  <li key={prod.id} className="text-sm bg-gray-100 p-2 rounded">
                    {prod.name} - ${prod.price} (Stock: {prod.stock_quantity})
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>

        {/* Users Test */}
        <div className="border rounded-lg p-4">
          <h2 className="text-xl font-semibold mb-2">Usuarios del Sistema</h2>
          {results.users?.error ? (
            <div className="text-red-600">Error: {results.users.error.message}</div>
          ) : (
            <div>
              <div className="text-green-600 mb-2">✅ Conectado exitosamente</div>
              <div className="text-sm">Total: {results.users?.data?.length || 0} usuarios</div>
              <ul className="mt-2 space-y-1">
                {results.users?.data?.map((user: any, index: number) => (
                  <li key={index} className="text-sm bg-gray-100 p-2 rounded">
                    {user.email} - {user.full_name}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>

        {/* Roles Test */}
        <div className="border rounded-lg p-4">
          <h2 className="text-xl font-semibold mb-2">Roles de Usuario</h2>
          {results.roles?.error ? (
            <div className="text-red-600">Error: {results.roles.error.message}</div>
          ) : (
            <div>
              <div className="text-green-600 mb-2">✅ Conectado exitosamente</div>
              <div className="text-sm">Total: {results.roles?.data?.length || 0} roles</div>
              <ul className="mt-2 space-y-1">
                {results.roles?.data?.map((role: any) => (
                  <li key={role.name} className="text-sm bg-gray-100 p-2 rounded">
                    {role.display_name} ({role.name})
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </div>

      <div className="mt-8 p-4 bg-blue-50 rounded-lg">
        <h3 className="font-semibold text-blue-800">Próximos pasos:</h3>
        <ul className="mt-2 text-sm text-blue-700 space-y-1">
          <li>• Prueba el login con: manager@barvip.com / manager123</li>
          <li>• Accede al dashboard y verifica todas las funciones</li>
          <li>• Prueba el sistema POS con los productos creados</li>
          <li>• Verifica que las notificaciones por email funcionen</li>
        </ul>
      </div>
    </div>
  )
}
